"""
News management domain module.
Handles reading, creating, and updating news items.
"""

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List

from ..utils.file_utils import (copy_file_with_rename, file_exists,
                                get_file_extension, list_files_in_directory,
                                read_file_content, write_file_content)


@dataclass
class News:
    """News item data model."""
    title: str = ""
    date: str = ""  # YYYY-MM-DD format
    picture_path: str = ""
    tag: str = "news"
    content: str = ""
    file_path: str = ""
    slug: str = ""  # One-word description
    
    def to_markdown(self) -> str:
        """Convert news data to markdown file content."""
        content = "---\n"
        content += f"title: {self.title}\n"
        content += f"picture-path: {self.picture_path}\n"
        content += f"date: {self.date}\n"
        content += f"tag: {self.tag}\n"
        content += "layout: news\n"
        content += "---\n"
        
        if self.content:
            content += f"\n{self.content}\n"
        
        return content
    
    @classmethod
    def from_markdown(cls, content: str, file_path: str = "") -> 'News':
        """Parse news data from markdown file content."""
        news = cls(file_path=file_path)
        
        # Extract front matter
        front_matter_match = re.search(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
        if not front_matter_match:
            return news
        
        front_matter = front_matter_match.group(1)
        
        # Parse front matter fields
        field_mappings = {
            'title': 'title',
            'date': 'date',
            'picture-path': 'picture_path',
            'tag': 'tag',
        }
        
        for yaml_key, attr_name in field_mappings.items():
            pattern = rf'^{re.escape(yaml_key)}:\s*(.*)$'
            match = re.search(pattern, front_matter, re.MULTILINE)
            if match:
                value = match.group(1).strip()
                setattr(news, attr_name, value)
        
        # Extract content (after front matter)
        content_match = re.search(r'^---\s*\n.*?\n---\s*\n(.*)$', content, re.DOTALL)
        if content_match:
            news.content = content_match.group(1).strip()
        
        # Extract slug from filename
        if file_path:
            filename = os.path.basename(file_path)
            # news_YYYY_MM_DD_slug.md -> extract slug
            slug_match = re.search(r'news_\d{4}_\d{2}_\d{2}_(.+)\.md$', filename)
            if slug_match:
                news.slug = slug_match.group(1)
        
        return news
    
    def generate_filename(self) -> str:
        """Generate the filename for this news item."""
        if not self.date or not self.slug:
            return ""
        
        # Convert date from YYYY-MM-DD to YYYY_MM_DD
        date_parts = self.date.replace('-', '_')
        return f"news_{date_parts}_{self.slug}.md"
    
    def generate_picture_filename(self, original_extension: str) -> str:
        """Generate the picture filename for this news item."""
        if not self.date or not self.slug:
            return ""
        
        date_parts = self.date.replace('-', '_')
        return f"news_{date_parts}_{self.slug}{original_extension}"


class NewsManager:
    """Manages news data operations."""
    
    def __init__(self, root_folder: str):
        """
        Initialize the news manager.
        
        Args:
            root_folder: Path to the website root folder
        """
        self.root_folder = root_folder
        self.news_dir = os.path.join(root_folder, '_notes')
        self.pictures_dir = os.path.join(root_folder, 'assets', 'news_pictures')
    
    def get_all_news(self) -> List[News]:
        """
        Get all news items from the _notes directory.
        
        Returns:
            List of News objects sorted by date (newest first)
        """
        news_items = []
        
        news_files = list_files_in_directory(self.news_dir, '.md')
        
        for file_path in news_files:
            filename = os.path.basename(str(file_path))
            # Only process news files (news_*.md)
            if not filename.startswith('news_'):
                continue
            
            try:
                content = read_file_content(str(file_path))
                news = News.from_markdown(content, str(file_path))
                if news.title:  # Only add if valid
                    news_items.append(news)
            except Exception:
                continue
        
        # Sort by date (newest first)
        news_items.sort(key=lambda n: n.date, reverse=True)
        
        return news_items
    
    def create_news(self, news: News, picture_source: str = None) -> str:
        """
        Create a new news file and optionally copy the picture.
        
        Args:
            news: The News object to create
            picture_source: Path to the source picture file
            
        Returns:
            Path to the created news file
        """
        # Generate filename
        filename = news.generate_filename()
        if not filename:
            raise ValueError("Cannot generate filename. Ensure date and slug are set.")
        
        file_path = os.path.join(self.news_dir, filename)
        
        # Handle picture
        if picture_source and file_exists(picture_source):
            # Generate picture filename
            extension = get_file_extension(picture_source)
            picture_filename = news.generate_picture_filename(extension)
            
            # Set the picture path (relative to assets/)
            news.picture_path = f"news_pictures/{picture_filename}"
            
            # Copy picture
            copy_file_with_rename(picture_source, self.pictures_dir, picture_filename)
        
        # Write news file
        content = news.to_markdown()
        write_file_content(file_path, content)
        news.file_path = file_path
        
        return file_path
    
    def check_picture_exists(self, picture_filename: str) -> bool:
        """Check if a picture with the given filename already exists."""
        return file_exists(os.path.join(self.pictures_dir, picture_filename))
    
    def check_news_file_exists(self, news: News) -> bool:
        """Check if a news file with the generated filename already exists."""
        filename = news.generate_filename()
        if not filename:
            return False
        return file_exists(os.path.join(self.news_dir, filename))
    
    def get_news_directory(self) -> str:
        """Get the path to the news directory."""
        return self.news_dir
    
    def get_pictures_directory(self) -> str:
        """Get the path to the news pictures directory."""
        return self.pictures_dir
