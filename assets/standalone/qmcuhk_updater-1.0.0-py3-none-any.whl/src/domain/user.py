"""
User management domain module.
Handles user registration, login, and persistence.
"""

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class User:
    """User data model."""
    username: str
    github_account: str = ""
    root_folder: str = ""
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'User':
        return cls(
            username=data.get('username', ''),
            github_account=data.get('github_account', ''),
            root_folder=data.get('root_folder', '')
        )


class UserManager:
    """Manages user data persistence and operations."""
    
    def __init__(self, data_file: str = None):
        """
        Initialize the user manager.
        
        Args:
            data_file: Path to the JSON file storing user data.
                      Defaults to '~/.qmcuhk_updater/users.json' in user's home.
        """
        if data_file is None:
            # Store in user's home directory for portability
            data_dir = Path.home() / '.qmcuhk_updater'
            data_dir.mkdir(exist_ok=True)
            self.data_file = str(data_dir / 'users.json')
        else:
            self.data_file = data_file
        
        self._users: List[User] = []
        self._last_user: Optional[str] = None
        self._current_user: Optional[User] = None
        
        self._load_data()
    
    def _load_data(self) -> None:
        """Load user data from the JSON file."""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self._users = [User.from_dict(u) for u in data.get('users', [])]
                    self._last_user = data.get('last_user')
            except (json.JSONDecodeError, IOError):
                self._users = []
                self._last_user = None
        else:
            self._users = []
            self._last_user = None
    
    def _save_data(self) -> None:
        """Save user data to the JSON file."""
        data = {
            'users': [u.to_dict() for u in self._users],
            'last_user': self._last_user
        }
        
        # Ensure directory exists
        os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
        
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    
    def get_all_users(self) -> List[User]:
        """Get all registered users."""
        return self._users.copy()
    
    def get_user(self, username: str) -> Optional[User]:
        """Get a user by username."""
        for user in self._users:
            if user.username.lower() == username.lower():
                return user
        return None
    
    def get_last_user(self) -> Optional[User]:
        """Get the last logged-in user."""
        if self._last_user:
            return self.get_user(self._last_user)
        return None
    
    def get_current_user(self) -> Optional[User]:
        """Get the currently logged-in user."""
        return self._current_user
    
    def register_user(self, username: str, github_account: str = "", 
                      root_folder: str = "") -> User:
        """
        Register a new user or update existing user.
        
        Args:
            username: The user's display name
            github_account: Optional GitHub account
            root_folder: Path to the website root folder
            
        Returns:
            The created or updated User object
        """
        existing = self.get_user(username)
        
        if existing:
            # Update existing user
            existing.github_account = github_account or existing.github_account
            existing.root_folder = root_folder or existing.root_folder
            user = existing
        else:
            # Create new user
            user = User(
                username=username,
                github_account=github_account,
                root_folder=root_folder
            )
            self._users.append(user)
        
        self._save_data()
        return user
    
    def login(self, username: str) -> Optional[User]:
        """
        Log in a user.
        
        Args:
            username: The username to log in
            
        Returns:
            The User object if found, None otherwise
        """
        user = self.get_user(username)
        if user:
            self._current_user = user
            self._last_user = user.username
            self._save_data()
        return user
    
    def logout(self) -> None:
        """Log out the current user."""
        self._current_user = None
    
    def update_user_root_folder(self, username: str, root_folder: str) -> bool:
        """
        Update a user's root folder.
        
        Args:
            username: The username
            root_folder: The new root folder path
            
        Returns:
            True if successful, False if user not found
        """
        user = self.get_user(username)
        if user:
            user.root_folder = root_folder
            self._save_data()
            return True
        return False
    
    def delete_user(self, username: str) -> bool:
        """
        Delete a user.
        
        Args:
            username: The username to delete
            
        Returns:
            True if deleted, False if not found
        """
        user = self.get_user(username)
        if user:
            self._users.remove(user)
            if self._last_user == username:
                self._last_user = self._users[0].username if self._users else None
            if self._current_user and self._current_user.username == username:
                self._current_user = None
            self._save_data()
            return True
        return False
    
    def validate_root_folder(self, root_folder: str) -> bool:
        """
        Validate that a root folder is a valid QMCUHK website directory.
        Checks for expected subdirectories.
        
        Args:
            root_folder: Path to check
            
        Returns:
            True if valid, False otherwise
        """
        if not os.path.isdir(root_folder):
            return False
        
        # Check for expected directories
        expected_dirs = ['_members', '_data', '_pages', '_notes', 'assets']
        for dir_name in expected_dirs:
            if not os.path.isdir(os.path.join(root_folder, dir_name)):
                return False
        
        return True
