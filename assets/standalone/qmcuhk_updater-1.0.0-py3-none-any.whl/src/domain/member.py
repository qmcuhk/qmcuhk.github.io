"""
Member management domain module.
Handles reading, creating, and updating member data.
"""

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..utils.file_utils import (copy_file_with_rename, file_exists,
                                get_file_extension, list_files_in_directory,
                                read_file_content, sanitize_filename,
                                write_file_content)


@dataclass
class Member:
    """Member data model."""
    name: str
    title: str = ""
    photo_path: str = ""
    affiliation_1: str = "The Chinese University of HK"
    affiliation_2: str = ""
    bachelor: str = ""
    master: str = ""
    phd: str = ""
    email: str = ""
    twitter: str = ""
    github: str = ""
    linkedin: str = ""
    start_date: str = ""
    end_date: str = ""
    post_stay_position: str = ""
    ordering: int = 10
    bio: str = ""
    file_path: str = ""
    
    def to_markdown(self) -> str:
        """Convert member data to markdown file content."""
        content = "---\n"
        content += f"name: {self.name}\n"
        content += f"title: {self.title}\n"
        content += f"photo-path: {self.photo_path}\n"
        content += f"affiliation-1: {self.affiliation_1}\n"
        content += f"affiliation-2: {self.affiliation_2}\n"
        content += f"bachelor: {self.bachelor}\n"
        content += f"master: {self.master}\n"
        content += f"phd: {self.phd}\n"
        content += f"email: {self.email}\n"
        content += f"twitter: {self.twitter}\n"
        content += f"github: {self.github}\n"
        content += f"linkedin: {self.linkedin}\n"
        content += f"start_date: {self.start_date}\n"
        content += f"end_date: {self.end_date}\n"
        content += f"post-stay-position: {self.post_stay_position}\n"
        content += f"ordering: {self.ordering}\n"
        content += "layout: members\n"
        content += "---\n"
        
        if self.bio:
            content += f"\n{self.bio}\n"
        
        return content
    
    @classmethod
    def from_markdown(cls, content: str, file_path: str = "") -> 'Member':
        """Parse member data from markdown file content."""
        member = cls(name="", file_path=file_path)
        
        # Extract front matter
        front_matter_match = re.search(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
        if not front_matter_match:
            return member
        
        front_matter = front_matter_match.group(1)
        
        # Parse front matter fields
        field_mappings = {
            'name': 'name',
            'title': 'title',
            'photo-path': 'photo_path',
            'affiliation-1': 'affiliation_1',
            'affiliation-2': 'affiliation_2',
            'bachelor': 'bachelor',
            'master': 'master',
            'phd': 'phd',
            'email': 'email',
            'twitter': 'twitter',
            'github': 'github',
            'linkedin': 'linkedin',
            'start_date': 'start_date',
            'end_date': 'end_date',
            'post-stay-position': 'post_stay_position',
            'ordering': 'ordering',
        }
        
        for yaml_key, attr_name in field_mappings.items():
            pattern = rf'^{re.escape(yaml_key)}:\s*(.*)$'
            match = re.search(pattern, front_matter, re.MULTILINE)
            if match:
                value = match.group(1).strip()
                if attr_name == 'ordering':
                    try:
                        value = int(value) if value else 10
                    except ValueError:
                        value = 10
                setattr(member, attr_name, value)
        
        # Extract bio (content after front matter)
        bio_match = re.search(r'^---\s*\n.*?\n---\s*\n(.*)$', content, re.DOTALL)
        if bio_match:
            member.bio = bio_match.group(1).strip()
        
        return member


class MemberManager:
    """Manages member data operations."""
    
    def __init__(self, root_folder: str):
        """
        Initialize the member manager.
        
        Args:
            root_folder: Path to the website root folder
        """
        self.root_folder = root_folder
        self.members_dir = os.path.join(root_folder, '_members')
        self.photos_dir = os.path.join(root_folder, 'assets', 'web_pictures')
    
    def get_all_members(self) -> List[Member]:
        """
        Get all members from the _members directory.
        
        Returns:
            List of Member objects sorted by ordering
        """
        members = []
        
        member_files = list_files_in_directory(self.members_dir, '.md')
        
        for file_path in member_files:
            try:
                content = read_file_content(str(file_path))
                member = Member.from_markdown(content, str(file_path))
                if member.name:  # Only add if valid
                    members.append(member)
            except Exception:
                continue
        
        # Sort by ordering number
        members.sort(key=lambda m: m.ordering)
        
        return members
    
    def get_member_photo_path(self, member: Member) -> Optional[str]:
        """
        Get the full path to a member's photo.
        
        Args:
            member: The Member object
            
        Returns:
            Full path to the photo or None if not found
        """
        if not member.photo_path:
            return None
        
        photo_path = os.path.join(self.photos_dir, member.photo_path)
        if file_exists(photo_path):
            return photo_path
        
        return None
    
    def create_member(self, member: Member, photo_source: str = None) -> str:
        """
        Create a new member file and optionally copy the photo.
        
        Args:
            member: The Member object to create
            photo_source: Path to the source photo file
            
        Returns:
            Path to the created member file
        """
        # Generate filename from name
        filename = sanitize_filename(member.name) + '.md'
        file_path = os.path.join(self.members_dir, filename)
        
        # Handle photo
        if photo_source and file_exists(photo_source):
            # Generate photo filename
            photo_filename = sanitize_filename(member.name) + get_file_extension(photo_source)
            member.photo_path = photo_filename
            
            # Copy photo
            copy_file_with_rename(photo_source, self.photos_dir, photo_filename)
        
        # Write member file
        content = member.to_markdown()
        write_file_content(file_path, content)
        member.file_path = file_path
        
        return file_path
    
    def update_member(self, member: Member) -> bool:
        """
        Update an existing member file.
        
        Args:
            member: The Member object with updated data
            
        Returns:
            True if successful, False otherwise
        """
        if not member.file_path or not file_exists(member.file_path):
            return False
        
        content = member.to_markdown()
        write_file_content(member.file_path, content)
        return True
    
    def check_photo_exists(self, photo_filename: str) -> bool:
        """Check if a photo with the given filename already exists."""
        return file_exists(os.path.join(self.photos_dir, photo_filename))
    
    def copy_member_photo(self, source_path: str, photo_filename: str) -> str:
        """
        Copy a photo to the photos directory.
        
        Args:
            source_path: Path to the source photo
            photo_filename: Desired filename for the photo
            
        Returns:
            Full path to the copied photo
        """
        return copy_file_with_rename(source_path, self.photos_dir, photo_filename)
