# Domain layer - business logic and data models
