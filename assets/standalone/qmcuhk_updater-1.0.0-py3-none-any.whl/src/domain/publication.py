"""
Publication management domain module.
Handles reading, creating, and updating publication data.
"""

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

import yaml

from ..utils.api_utils import PublicationData, fetch_publication_data
from ..utils.file_utils import (copy_file_with_rename, file_exists,
                                read_file_content, write_file_content)


@dataclass
class Publication:
    """Publication data model."""
    title: str = ""
    date: str = ""
    journal: str = ""
    arxiv: str = ""
    preprint: Optional[bool] = None
    doi: str = ""
    pdf_name: Optional[str] = None
    authors: str = ""
    authors_short: str = ""
    picture_path: str = ""
    description: int = 1
    
    def to_dict(self) -> dict:
        """Convert to YAML-compatible dictionary."""
        data = {
            'title': self.title,
            'date': f"'{self.date}'" if self.date else '',
            'journal': self.journal,
            'arxiv': self.arxiv,
            'preprint': self.preprint if self.preprint else None,
            'doi': self.doi,
            'pdf-name': self.pdf_name,
            'authors': self.authors,
            'picture-path': self.picture_path,
            'description': self.description,
        }
        
        if self.authors_short:
            data['authors-short'] = self.authors_short
        
        return data
    
    def to_yaml_entry(self) -> str:
        """Convert to a YAML list entry string."""
        lines = [f"- title: {self.title}"]
        lines.append(f"  date: '{self.date}'")
        lines.append(f"  journal: {self.journal}")
        lines.append(f"  arxiv: {self.arxiv}")
        
        if self.preprint:
            lines.append(f"  preprint: true")
        else:
            lines.append(f"  preprint: null")
        
        lines.append(f"  doi: {self.doi}")
        lines.append(f"  pdf-name: {self.pdf_name if self.pdf_name else 'null'}")
        lines.append(f"  authors: {self.authors}")
        
        if self.authors_short:
            lines.append(f"  authors-short: {self.authors_short}")
        
        lines.append(f"  picture-path: {self.picture_path}")
        lines.append(f"  description: {self.description}")
        
        return '\n'.join(lines)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Publication':
        """Create Publication from dictionary."""
        return cls(
            title=data.get('title', ''),
            date=str(data.get('date', '')).strip("'"),
            journal=data.get('journal', ''),
            arxiv=data.get('arxiv', ''),
            preprint=data.get('preprint'),
            doi=data.get('doi', ''),
            pdf_name=data.get('pdf-name'),
            authors=data.get('authors', ''),
            authors_short=data.get('authors-short', ''),
            picture_path=data.get('picture-path', ''),
            description=data.get('description', 1),
        )
    
    @classmethod
    def from_api_data(cls, api_data: PublicationData) -> 'Publication':
        """Create Publication from API data."""
        return cls(
            title=api_data.title,
            date=api_data.date,
            journal=api_data.journal,
            arxiv=api_data.arxiv,
            preprint=api_data.is_preprint,
            doi=api_data.doi,
            authors=api_data.authors,
        )


class PublicationManager:
    """Manages publication data operations."""
    
    def __init__(self, root_folder: str):
        """
        Initialize the publication manager.
        
        Args:
            root_folder: Path to the website root folder
        """
        self.root_folder = root_folder
        self.publications_file = os.path.join(root_folder, '_data', 'publications.yml')
        self.pictures_dir = os.path.join(root_folder, 'assets', 'publications_pictures')
    
    def get_all_publications(self) -> List[Publication]:
        """
        Get all publications from the publications.yml file.
        
        Returns:
            List of Publication objects
        """
        if not file_exists(self.publications_file):
            return []
        
        try:
            content = read_file_content(self.publications_file)
            data = yaml.safe_load(content)
            
            if not data:
                return []
            
            return [Publication.from_dict(item) for item in data]
        except Exception:
            return []
    
    def get_preprints(self) -> List[Publication]:
        """
        Get all preprints (publications with preprint: true).
        
        Returns:
            List of Publication objects that are preprints
        """
        all_pubs = self.get_all_publications()
        return [p for p in all_pubs if p.preprint is True]
    
    def add_publication(self, publication: Publication, picture_source: str = None) -> bool:
        """
        Add a new publication to the top of the list.
        
        Args:
            publication: The Publication object to add
            picture_source: Path to the source picture file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Handle picture
            if picture_source and file_exists(picture_source):
                copy_file_with_rename(
                    picture_source, 
                    self.pictures_dir, 
                    publication.picture_path
                )
            
            # Read existing content
            if file_exists(self.publications_file):
                content = read_file_content(self.publications_file)
            else:
                content = ""
            
            # Add new entry at the top
            new_entry = publication.to_yaml_entry()
            
            if content.strip():
                new_content = new_entry + '\n\n' + content
            else:
                new_content = new_entry + '\n'
            
            write_file_content(self.publications_file, new_content)
            return True
            
        except Exception:
            return False
    
    def update_preprint_to_published(self, title: str, doi: str) -> bool:
        """
        Update a preprint to published status.
        
        Args:
            title: The publication title to find
            doi: The DOI URL to set
            
        Returns:
            True if successful, False otherwise
        """
        if not file_exists(self.publications_file):
            return False
        
        try:
            content = read_file_content(self.publications_file)
            
            # Find and update the publication
            # This is a simple approach - find the title and update nearby preprint/doi
            lines = content.split('\n')
            new_lines = []
            found_title = False
            title_block_indent = 0
            in_target_block = False
            
            for i, line in enumerate(lines):
                # Check if this is the start of our target publication
                if f'title: {title}' in line or f"title: '{title}'" in line:
                    found_title = True
                    in_target_block = True
                    title_block_indent = len(line) - len(line.lstrip())
                    new_lines.append(line)
                    continue
                
                # Check if we've moved to a new publication entry
                if in_target_block and line.strip().startswith('- title:'):
                    in_target_block = False
                
                # Update preprint and doi fields within the target block
                if in_target_block:
                    if 'preprint:' in line:
                        indent = len(line) - len(line.lstrip())
                        new_lines.append(' ' * indent + 'preprint: null')
                        continue
                    elif 'doi:' in line and doi:
                        indent = len(line) - len(line.lstrip())
                        new_lines.append(' ' * indent + f'doi: {doi}')
                        continue
                
                new_lines.append(line)
            
            if found_title:
                write_file_content(self.publications_file, '\n'.join(new_lines))
                return True
            
            return False
            
        except Exception:
            return False
    
    def fetch_from_identifier(self, identifier: str) -> Optional[Publication]:
        """
        Fetch publication data from DOI or arXiv identifier.
        
        Args:
            identifier: DOI, DOI URL, arXiv ID, or arXiv URL
            
        Returns:
            Publication object or None if fetch failed
        """
        api_data = fetch_publication_data(identifier)
        if api_data:
            return Publication.from_api_data(api_data)
        return None
    
    def check_picture_exists(self, picture_filename: str) -> bool:
        """Check if a picture with the given filename already exists."""
        return file_exists(os.path.join(self.pictures_dir, picture_filename))
    
    def get_publications_file_path(self) -> str:
        """Get the path to the publications file."""
        return self.publications_file
