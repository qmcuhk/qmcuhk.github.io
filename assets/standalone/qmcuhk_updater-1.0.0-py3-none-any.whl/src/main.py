#!/usr/bin/env python3
"""
QMCUHK Website Updater - Main entry point.

A PyQt5 GUI application for maintaining the QMCUHK research group website.
"""

import sys

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import QApplication

from src.views.main_window import MainWindow


def main():
    """Main entry point for the application."""
    # Enable High DPI scaling
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    # Create application
    app = QApplication(sys.argv)
    app.setApplicationName("QMCUHK Website Updater")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("QMCUHK")
    
    # Set default font
    font = QFont("Helvetica Neue")
    font.setPointSize(13)
    app.setFont(font)
    
    # Create and show main window
    window = MainWindow()
    window.show()
    
    # Run the application
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
