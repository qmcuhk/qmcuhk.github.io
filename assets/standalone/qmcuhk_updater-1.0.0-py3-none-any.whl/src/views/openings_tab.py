"""
Openings tab - simple tab for opening the openings.md file in editor.
"""

import os

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (QHBoxLayout, QLabel, QPushButton, QVBoxLayout,
                             QWidget)

from ..utils.file_utils import open_file_in_editor, open_in_file_explorer


class OpeningsTab(QWidget):
    """
    Simple tab for editing openings page.
    Just opens the file in the default text editor.
    """
    
    log_message = pyqtSignal(str, str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._root_folder = None
        self._openings_file = None
        self._setup_ui()
    
    def _setup_ui(self):
        """Set up the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(20)
        
        # Center content
        layout.addStretch()
        
        # Icon
        icon_label = QLabel("📋")
        icon_label.setStyleSheet("font-size: 64px;")
        icon_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(icon_label)
        
        # Title
        title = QLabel("Openings Page")
        title.setObjectName("sectionTitle")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 24px; font-weight: 600;")
        layout.addWidget(title)
        
        # Description
        desc = QLabel(
            "The openings page contains information about available positions.\n"
            "Click the button below to edit it in your default text editor."
        )
        desc.setAlignment(Qt.AlignCenter)
        desc.setStyleSheet("color: #6c757d; font-size: 14px;")
        desc.setWordWrap(True)
        layout.addWidget(desc)
        
        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        # Open folder button
        folder_btn = QPushButton("📁 Open Folder")
        folder_btn.setObjectName("secondaryButton")
        folder_btn.clicked.connect(self._open_folder)
        btn_layout.addWidget(folder_btn)
        
        # Open in editor button
        self.edit_btn = QPushButton("Edit in Editor")
        self.edit_btn.setMinimumWidth(150)
        self.edit_btn.clicked.connect(self._open_in_editor)
        btn_layout.addWidget(self.edit_btn)
        
        btn_layout.addStretch()
        layout.addLayout(btn_layout)
        
        # File path display
        self.file_label = QLabel()
        self.file_label.setAlignment(Qt.AlignCenter)
        self.file_label.setStyleSheet("color: #6c757d; font-size: 11px; margin-top: 20px;")
        layout.addWidget(self.file_label)
        
        layout.addStretch()
    
    def set_root_folder(self, root_folder: str):
        """Set the website root folder."""
        self._root_folder = root_folder
        self._openings_file = os.path.join(root_folder, '_pages', 'openings.md')
        self.file_label.setText(f"File: {self._openings_file}")
    
    def _open_in_editor(self):
        """Open the openings file in the default editor."""
        if not self._openings_file:
            return
        
        if os.path.exists(self._openings_file):
            self.log_message.emit("Opening openings.md in editor", "info")
            open_file_in_editor(self._openings_file)
        else:
            self.log_message.emit(f"File not found: {self._openings_file}", "error")
    
    def _open_folder(self):
        """Open the _pages folder in file explorer."""
        if self._root_folder:
            pages_dir = os.path.join(self._root_folder, '_pages')
            if os.path.exists(pages_dir):
                self.log_message.emit("Opened _pages folder", "info")
                open_in_file_explorer(pages_dir)
