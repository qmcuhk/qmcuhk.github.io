"""
Login panel widget for user authentication and registration.
"""

import os

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QFileDialog,
                             QFormLayout, QFrame, QHBoxLayout, QLabel,
                             QLineEdit, QMessageBox, QPushButton, QVBoxLayout,
                             QWidget)

from ..domain.user import User, UserManager


class RegisterDialog(QDialog):
    """Dialog for registering a new user."""
    
    def __init__(self, user_manager: UserManager, parent=None):
        super().__init__(parent)
        self.user_manager = user_manager
        self.user = None
        self._setup_ui()
    
    def _setup_ui(self):
        """Set up the dialog UI."""
        self.setWindowTitle("Register New User")
        self.setMinimumWidth(450)
        self.setModal(True)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.setContentsMargins(24, 24, 24, 24)
        
        # Title
        title = QLabel("Create New User")
        title.setStyleSheet("font-size: 18px; font-weight: 600; color: #1a1a2e;")
        layout.addWidget(title)
        
        # Form
        form = QFormLayout()
        form.setSpacing(12)
        form.setLabelAlignment(Qt.AlignRight)
        
        # Username
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Enter your name")
        form.addRow("Username:", self.username_input)
        
        # GitHub (optional)
        self.github_input = QLineEdit()
        self.github_input.setPlaceholderText("your-github-username")
        form.addRow("GitHub:", self.github_input)
        
        layout.addLayout(form)
        
        # Folder selection
        folder_label = QLabel("Website Folder:")
        folder_label.setStyleSheet("font-weight: 500;")
        layout.addWidget(folder_label)
        
        folder_layout = QHBoxLayout()
        self.folder_input = QLineEdit()
        self.folder_input.setPlaceholderText("Select your website root folder")
        self.folder_input.setReadOnly(True)
        
        browse_btn = QPushButton("Browse")
        browse_btn.setObjectName("secondaryButton")
        browse_btn.setMaximumWidth(80)
        browse_btn.clicked.connect(self._browse_folder)
        
        folder_layout.addWidget(self.folder_input)
        folder_layout.addWidget(browse_btn)
        layout.addLayout(folder_layout)
        
        # Info text
        info = QLabel(
            "The website folder should contain: _members, _data, _pages, _notes, assets"
        )
        info.setStyleSheet("color: #6c757d; font-size: 11px;")
        info.setWordWrap(True)
        layout.addWidget(info)
        
        layout.addStretch()
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def _browse_folder(self):
        """Open folder browser dialog."""
        folder = QFileDialog.getExistingDirectory(
            self,
            "Select Website Root Folder",
            os.path.expanduser("~")
        )
        if folder:
            self.folder_input.setText(folder)
    
    def _accept(self):
        """Validate and accept the dialog."""
        username = self.username_input.text().strip()
        github = self.github_input.text().strip()
        folder = self.folder_input.text().strip()
        
        if not username:
            QMessageBox.warning(self, "Missing Information", "Please enter a username.")
            return
        
        if not folder:
            QMessageBox.warning(self, "Missing Information", "Please select a website folder.")
            return
        
        # Validate folder
        if not self.user_manager.validate_root_folder(folder):
            QMessageBox.warning(
                self,
                "Invalid Folder",
                "The selected folder doesn't appear to be a valid QMCUHK website folder.\n\n"
                "Expected directories: _members, _data, _pages, _notes, assets"
            )
            return
        
        # Check if username exists
        existing = self.user_manager.get_user(username)
        if existing:
            reply = QMessageBox.question(
                self,
                "User Exists",
                f"User '{username}' already exists. Do you want to update their settings?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        
        # Register user
        self.user = self.user_manager.register_user(username, github, folder)
        self.accept()
    
    def get_user(self) -> User:
        """Get the registered user."""
        return self.user


class LoginPanel(QFrame):
    """
    Login/registration panel with folder selection.
    Displays at the top when not logged in, moves to bottom when logged in.
    """
    
    # Signal emitted when user logs in successfully
    user_logged_in = pyqtSignal(User)
    # Signal emitted when user logs out
    user_logged_out = pyqtSignal()
    
    def __init__(self, user_manager: UserManager, parent=None):
        super().__init__(parent)
        self.setObjectName("loginPanel")
        self.user_manager = user_manager
        self._is_logged_in = False
        self._setup_ui()
        self._load_users()
    
    def _setup_ui(self):
        """Set up the UI components."""
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(16, 16, 16, 16)
        self.main_layout.setSpacing(12)
        
        # Login view
        self.login_widget = QWidget()
        self._setup_login_view()
        self.main_layout.addWidget(self.login_widget)
        
        # Logged in view (hidden by default)
        self.logged_in_widget = QWidget()
        self._setup_logged_in_view()
        self.logged_in_widget.hide()
        self.main_layout.addWidget(self.logged_in_widget)
    
    def _setup_login_view(self):
        """Set up the login view."""
        layout = QVBoxLayout(self.login_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)
        
        # Title
        title = QLabel("Welcome to QMCUHK Updater")
        title.setObjectName("sectionTitle")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 20px; font-weight: 600; margin-bottom: 8px;")
        layout.addWidget(title)
        
        # Center container with max width
        center_container = QWidget()
        center_container.setMaximumWidth(400)
        center_layout = QVBoxLayout(center_container)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(12)
        
        # User selection
        user_label = QLabel("Select User:")
        user_label.setStyleSheet("font-weight: 500;")
        center_layout.addWidget(user_label)
        
        self.user_combo = QComboBox()
        self.user_combo.setMinimumHeight(36)
        center_layout.addWidget(self.user_combo)
        
        # Login button
        self.login_btn = QPushButton("Login")
        self.login_btn.setMinimumHeight(40)
        self.login_btn.clicked.connect(self._login_existing_user)
        center_layout.addWidget(self.login_btn)
        
        # Register link
        register_layout = QHBoxLayout()
        register_label = QLabel("New user?")
        register_label.setStyleSheet("color: #6c757d;")
        
        self.register_btn = QPushButton("Register")
        self.register_btn.setObjectName("secondaryButton")
        self.register_btn.setMaximumWidth(100)
        self.register_btn.clicked.connect(self._show_register_dialog)
        
        register_layout.addStretch()
        register_layout.addWidget(register_label)
        register_layout.addWidget(self.register_btn)
        register_layout.addStretch()
        center_layout.addLayout(register_layout)
        
        # Add centered container
        layout.addWidget(center_container, alignment=Qt.AlignCenter)
    
    def _setup_logged_in_view(self):
        """Set up the logged in view."""
        layout = QHBoxLayout(self.logged_in_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        
        # User info
        self.logged_in_label = QLabel()
        self.logged_in_label.setStyleSheet("color: #495057;")
        layout.addWidget(self.logged_in_label)
        
        layout.addStretch()
        
        # Change folder button
        self.change_folder_btn = QPushButton("Change Folder")
        self.change_folder_btn.setObjectName("secondaryButton")
        self.change_folder_btn.clicked.connect(self._change_folder)
        layout.addWidget(self.change_folder_btn)
        
        # Logout button
        self.logout_btn = QPushButton("Logout")
        self.logout_btn.setObjectName("secondaryButton")
        self.logout_btn.clicked.connect(self._logout)
        layout.addWidget(self.logout_btn)
    
    def _load_users(self):
        """Load existing users into the combo box."""
        self.user_combo.clear()
        users = self.user_manager.get_all_users()
        
        if not users:
            self.user_combo.addItem("No users registered")
            self.user_combo.setEnabled(False)
            self.login_btn.setEnabled(False)
        else:
            self.user_combo.setEnabled(True)
            self.login_btn.setEnabled(True)
            
            last_user = self.user_manager.get_last_user()
            selected_index = 0
            
            for i, user in enumerate(users):
                self.user_combo.addItem(user.username, user)
                if last_user and user.username == last_user.username:
                    selected_index = i
            
            self.user_combo.setCurrentIndex(selected_index)
    
    def _login_existing_user(self):
        """Log in the selected existing user."""
        if self.user_combo.count() == 0 or not self.user_combo.isEnabled():
            return
        
        user = self.user_combo.currentData()
        if user:
            # Validate root folder still exists
            if not self.user_manager.validate_root_folder(user.root_folder):
                QMessageBox.warning(
                    self,
                    "Invalid Folder",
                    f"The website folder '{user.root_folder}' is no longer valid.\n"
                    "Please select a new folder."
                )
                self._change_folder_for_user(user)
                return
            
            self.user_manager.login(user.username)
            self._show_logged_in_view(user)
            self.user_logged_in.emit(user)
    
    def _show_register_dialog(self):
        """Show the registration dialog."""
        dialog = RegisterDialog(self.user_manager, self)
        if dialog.exec_() == QDialog.Accepted:
            user = dialog.get_user()
            if user:
                self.user_manager.login(user.username)
                self._load_users()
                self._show_logged_in_view(user)
                self.user_logged_in.emit(user)
    
    def _show_logged_in_view(self, user: User):
        """Switch to logged in view."""
        self._is_logged_in = True
        self.logged_in_label.setText(
            f"<b>Logged in as:</b> {user.username} | "
            f"<b>Folder:</b> {user.root_folder}"
        )
        self.login_widget.hide()
        self.logged_in_widget.show()
    
    def _show_login_view(self):
        """Switch to login view."""
        self._is_logged_in = False
        self.logged_in_widget.hide()
        self.login_widget.show()
    
    def _logout(self):
        """Log out the current user."""
        self.user_manager.logout()
        self._show_login_view()
        self.user_logged_out.emit()
    
    def _change_folder(self):
        """Change the current user's folder."""
        user = self.user_manager.get_current_user()
        if user:
            self._change_folder_for_user(user)
    
    def _change_folder_for_user(self, user: User):
        """Change folder for a specific user."""
        folder = QFileDialog.getExistingDirectory(
            self,
            "Select Website Root Folder",
            user.root_folder if os.path.exists(user.root_folder) else os.path.expanduser("~")
        )
        if folder:
            if not self.user_manager.validate_root_folder(folder):
                QMessageBox.warning(
                    self,
                    "Invalid Folder",
                    "The selected folder doesn't appear to be a valid QMCUHK website folder."
                )
                return
            
            self.user_manager.update_user_root_folder(user.username, folder)
            user.root_folder = folder
            self._show_logged_in_view(user)
            self.user_logged_in.emit(user)
    
    def is_logged_in(self) -> bool:
        """Check if a user is currently logged in."""
        return self._is_logged_in
    
    def get_current_user(self) -> User:
        """Get the current logged in user."""
        return self.user_manager.get_current_user()
