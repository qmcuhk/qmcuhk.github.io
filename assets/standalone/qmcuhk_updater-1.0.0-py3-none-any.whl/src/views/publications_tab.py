"""
Publications tab for adding and editing publications.
"""

import os

from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtWidgets import (QCheckBox, QDialog, QDialogButtonBox, QFormLayout,
                             QFrame, QHBoxLayout, QInputDialog, QLabel,
                             QLineEdit, QListWidget, QListWidgetItem,
                             QMessageBox, QPushButton, QScrollArea, QSplitter,
                             QTextEdit, QVBoxLayout, QWidget)

from ..domain.publication import Publication, PublicationManager
from ..utils.file_utils import open_file_in_editor, open_in_file_explorer
from .widgets.drag_drop_area import DragDropArea


class FetchWorker(QThread):
    """Worker thread for fetching publication data."""
    finished = pyqtSignal(object)  # Emits Publication or None
    error = pyqtSignal(str)
    
    def __init__(self, manager: PublicationManager, identifier: str):
        super().__init__()
        self.manager = manager
        self.identifier = identifier
    
    def run(self):
        try:
            pub = self.manager.fetch_from_identifier(self.identifier)
            self.finished.emit(pub)
        except Exception as e:
            self.error.emit(str(e))


class PublishDialog(QDialog):
    """Dialog for marking a preprint as published."""
    
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Mark as Published")
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout(self)
        
        # Info
        info = QLabel(f"Marking as published:\n<b>{title}</b>")
        info.setWordWrap(True)
        layout.addWidget(info)
        
        # DOI input
        doi_label = QLabel("Enter the DOI or DOI URL:")
        layout.addWidget(doi_label)
        
        self.doi_input = QLineEdit()
        self.doi_input.setPlaceholderText("https://doi.org/10.1103/PhysRevB.109.123456")
        layout.addWidget(self.doi_input)
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    
    def get_doi(self) -> str:
        return self.doi_input.text().strip()


class PublicationsTab(QWidget):
    """
    Tab for managing publications.
    Left panel: Form for adding publications with DOI/arXiv import
    Right panel: Preprints list for marking as published
    """
    
    log_message = pyqtSignal(str, str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._root_folder = None
        self._pub_manager = None
        self._fetch_worker = None
        self._setup_ui()
    
    def _setup_ui(self):
        """Set up the UI components."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        splitter = QSplitter(Qt.Horizontal)
        
        # Left panel - Form
        left_panel = QWidget()
        self._setup_left_panel(left_panel)
        splitter.addWidget(left_panel)
        
        # Right panel - Preprints
        right_panel = QWidget()
        self._setup_right_panel(right_panel)
        splitter.addWidget(right_panel)
        
        splitter.setSizes([600, 300])
        layout.addWidget(splitter)
    
    def _setup_left_panel(self, panel: QWidget):
        """Set up the left panel with the publication form."""
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(16)
        
        # Header
        header_layout = QHBoxLayout()
        title = QLabel("Add Publication")
        title.setObjectName("sectionTitle")
        header_layout.addWidget(title)
        header_layout.addStretch()
        
        # Open folder button
        folder_btn = QPushButton("📁")
        folder_btn.setObjectName("iconButton")
        folder_btn.setToolTip("Open publications pictures folder")
        folder_btn.clicked.connect(self._open_pictures_folder)
        header_layout.addWidget(folder_btn)
        
        # Gear button
        gear_btn = QPushButton("⚙️")
        gear_btn.setObjectName("iconButton")
        gear_btn.setToolTip("Open publications.yml in editor")
        gear_btn.clicked.connect(self._open_publications_file)
        header_layout.addWidget(gear_btn)
        
        layout.addLayout(header_layout)
        
        # Scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        
        form_container = QWidget()
        form_layout = QVBoxLayout(form_container)
        form_layout.setSpacing(12)
        
        # Import section (at top)
        import_frame = QFrame()
        import_frame.setObjectName("card")
        import_layout = QVBoxLayout(import_frame)
        import_layout.setContentsMargins(12, 12, 12, 12)
        
        import_label = QLabel("Import from DOI / arXiv")
        import_label.setStyleSheet("font-weight: 600;")
        import_layout.addWidget(import_label)
        
        import_row = QHBoxLayout()
        self.import_input = QLineEdit()
        self.import_input.setPlaceholderText("DOI, DOI URL, arXiv ID (2303.02865), or arXiv URL")
        import_row.addWidget(self.import_input)
        
        self.import_btn = QPushButton("Fetch")
        self.import_btn.clicked.connect(self._fetch_publication)
        import_row.addWidget(self.import_btn)
        
        import_layout.addLayout(import_row)
        
        self.import_status = QLabel()
        self.import_status.setStyleSheet("color: #6c757d; font-size: 12px;")
        self.import_status.hide()
        import_layout.addWidget(self.import_status)
        
        form_layout.addWidget(import_frame)
        
        # Manual form
        manual_label = QLabel("Or enter manually:")
        manual_label.setStyleSheet("font-weight: 500; margin-top: 8px;")
        form_layout.addWidget(manual_label)
        
        self.form = QFormLayout()
        self.form.setSpacing(12)
        self.form.setLabelAlignment(Qt.AlignRight)
        
        # Title
        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("Paper Title Here")
        self.form.addRow("Title:", self.title_input)
        
        # Authors
        self.authors_input = QLineEdit()
        self.authors_input.setPlaceholderText("Author One*, Author Two, Qisi Wang*")
        self.form.addRow("Authors:", self.authors_input)
        
        # Date
        self.date_input = QLineEdit()
        self.date_input.setPlaceholderText("2025-01-15")
        self.form.addRow("Date:", self.date_input)
        
        # Journal
        self.journal_input = QLineEdit()
        self.journal_input.setPlaceholderText("arXiv:2303.02865 or <b>Physical Review B</b> 109, 123456 (2024)")
        self.form.addRow("Journal:", self.journal_input)
        
        # Preprint checkbox (moved before URL fields)
        self.preprint_checkbox = QCheckBox("This is a preprint")
        self.preprint_checkbox.setChecked(True)
        self.preprint_checkbox.stateChanged.connect(self._on_preprint_toggled)
        self.form.addRow("", self.preprint_checkbox)
        
        # arXiv URL (shown for preprints)
        self.arxiv_label = QLabel("arXiv URL:")
        self.arxiv_input = QLineEdit()
        self.arxiv_input.setPlaceholderText("https://arxiv.org/abs/2303.02865")
        self.form.addRow(self.arxiv_label, self.arxiv_input)
        
        # DOI URL (shown for published papers)
        self.doi_label = QLabel("DOI URL:")
        self.doi_input = QLineEdit()
        self.doi_input.setPlaceholderText("https://doi.org/10.1103/PhysRevB.109.123456")
        self.form.addRow(self.doi_label, self.doi_input)
        
        # Initially hide DOI (since preprint is checked by default)
        self.doi_label.hide()
        self.doi_input.hide()
        
        form_layout.addLayout(self.form)
        
        # Picture section
        pic_label = QLabel("Publication Figure:")
        pic_label.setStyleSheet("font-weight: 500; margin-top: 8px;")
        form_layout.addWidget(pic_label)
        
        # Picture filename input
        pic_name_layout = QHBoxLayout()
        pic_name_label = QLabel("Filename:")
        self.pic_name_input = QLineEdit()
        self.pic_name_input.setPlaceholderText("2026_wang_nature.jpg")
        pic_name_layout.addWidget(pic_name_label)
        pic_name_layout.addWidget(self.pic_name_input)
        form_layout.addLayout(pic_name_layout)
        
        self.picture_drop = DragDropArea(
            placeholder_text="Drag & drop publication figure here"
        )
        form_layout.addWidget(self.picture_drop)
        
        form_layout.addStretch()
        
        scroll.setWidget(form_container)
        layout.addWidget(scroll)
        
        # Bottom buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        clear_btn = QPushButton("Clear")
        clear_btn.setObjectName("secondaryButton")
        clear_btn.clicked.connect(self._clear_form)
        btn_layout.addWidget(clear_btn)
        
        self.submit_btn = QPushButton("Submit")
        self.submit_btn.clicked.connect(self._submit_publication)
        btn_layout.addWidget(self.submit_btn)
        
        layout.addLayout(btn_layout)
    
    def _setup_right_panel(self, panel: QWidget):
        """Set up the right panel with preprints list."""
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)
        
        # Header
        title = QLabel("Preprints")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)
        
        # Load button
        self.load_preprints_btn = QPushButton("Load Preprints")
        self.load_preprints_btn.clicked.connect(self._load_preprints)
        layout.addWidget(self.load_preprints_btn)
        
        # Info
        info = QLabel("Select a preprint and click 'Mark as Published' to update it")
        info.setStyleSheet("color: #6c757d; font-size: 11px;")
        info.setWordWrap(True)
        layout.addWidget(info)
        
        # Preprints list
        self.preprints_list = QListWidget()
        self.preprints_list.setAlternatingRowColors(True)
        layout.addWidget(self.preprints_list)
        
        # Mark as published button
        self.publish_btn = QPushButton("Mark as Published")
        self.publish_btn.setObjectName("secondaryButton")
        self.publish_btn.clicked.connect(self._mark_as_published)
        layout.addWidget(self.publish_btn)
    
    def set_root_folder(self, root_folder: str):
        """Set the website root folder."""
        self._root_folder = root_folder
        self._pub_manager = PublicationManager(root_folder)
        self.preprints_list.clear()
    
    def _on_preprint_toggled(self, state: int):
        """Handle preprint checkbox toggle - show/hide arXiv and DOI fields."""
        is_preprint = state == Qt.Checked
        
        # Show arXiv for preprints, hide for published
        self.arxiv_label.setVisible(is_preprint)
        self.arxiv_input.setVisible(is_preprint)
        
        # Show DOI for published, hide for preprints
        self.doi_label.setVisible(not is_preprint)
        self.doi_input.setVisible(not is_preprint)
    
    def _fetch_publication(self):
        """Fetch publication data from DOI/arXiv."""
        if not self._pub_manager:
            QMessageBox.warning(self, "Error", "Please login first.")
            return
        
        identifier = self.import_input.text().strip()
        if not identifier:
            QMessageBox.warning(self, "Missing Input", "Please enter a DOI or arXiv identifier.")
            return
        
        self.import_btn.setEnabled(False)
        self.import_status.setText("Fetching...")
        self.import_status.show()
        self.log_message.emit(f"Fetching: {identifier}", "info")
        
        # Use worker thread for network request
        self._fetch_worker = FetchWorker(self._pub_manager, identifier)
        self._fetch_worker.finished.connect(self._on_fetch_finished)
        self._fetch_worker.error.connect(self._on_fetch_error)
        self._fetch_worker.start()
    
    def _on_fetch_finished(self, publication):
        """Handle fetch completion."""
        self.import_btn.setEnabled(True)
        
        if publication:
            self._fill_form(publication)
            self.import_status.setText("✓ Data fetched successfully")
            self.import_status.setStyleSheet("color: #28a745; font-size: 12px;")
            self.log_message.emit("Publication data fetched", "success")
        else:
            self.import_status.setText("✗ Could not fetch data")
            self.import_status.setStyleSheet("color: #dc3545; font-size: 12px;")
            self.log_message.emit("Failed to fetch publication data", "error")
    
    def _on_fetch_error(self, error_msg: str):
        """Handle fetch error."""
        self.import_btn.setEnabled(True)
        self.import_status.setText(f"✗ Error: {error_msg}")
        self.import_status.setStyleSheet("color: #dc3545; font-size: 12px;")
        self.log_message.emit(f"Fetch error: {error_msg}", "error")
    
    def _fill_form(self, pub: Publication):
        """Fill the form with publication data."""
        self.title_input.setText(pub.title)
        self.authors_input.setText(pub.authors)
        self.date_input.setText(pub.date)
        self.journal_input.setText(pub.journal)
        self.arxiv_input.setText(pub.arxiv)
        self.doi_input.setText(pub.doi)
        # Set checkbox - this will trigger _on_preprint_toggled to show/hide fields
        self.preprint_checkbox.setChecked(pub.preprint is True)
    
    def _clear_form(self):
        """Clear all form fields."""
        self.import_input.clear()
        self.import_status.hide()
        self.title_input.clear()
        self.authors_input.clear()
        self.date_input.clear()
        self.journal_input.clear()
        self.arxiv_input.clear()
        self.doi_input.clear()
        self.preprint_checkbox.setChecked(True)
        self.pic_name_input.clear()
        self.picture_drop.clear()
    
    def _submit_publication(self):
        """Submit the new publication."""
        if not self._pub_manager:
            QMessageBox.warning(self, "Error", "Please login first.")
            return
        
        # Validate
        title = self.title_input.text().strip()
        if not title:
            QMessageBox.warning(self, "Missing Information", "Please enter a title.")
            return
        
        # Get picture info
        pic_path = self.picture_drop.get_file_path()
        pic_name = self.pic_name_input.text().strip()
        
        if pic_path and not pic_name:
            QMessageBox.warning(self, "Missing Information", "Please enter a filename for the picture.")
            return
        
        if pic_name and self._pub_manager.check_picture_exists(pic_name):
            new_name, ok = QInputDialog.getText(
                self,
                "File Exists",
                f"Picture '{pic_name}' already exists.\nEnter a new filename:",
                text=pic_name
            )
            if not ok or not new_name:
                return
            pic_name = new_name.strip()
        
        # Create publication
        pub = Publication(
            title=title,
            authors=self.authors_input.text().strip(),
            date=self.date_input.text().strip(),
            journal=self.journal_input.text().strip(),
            arxiv=self.arxiv_input.text().strip(),
            doi=self.doi_input.text().strip(),
            preprint=True if self.preprint_checkbox.isChecked() else None,
            picture_path=pic_name,
        )
        
        try:
            success = self._pub_manager.add_publication(pub, pic_path)
            if success:
                self.log_message.emit(f"Added publication: {title[:50]}...", "success")
                QMessageBox.information(
                    self,
                    "Success",
                    f"Publication added successfully!"
                )
                self._clear_form()
            else:
                raise Exception("Failed to add publication")
                
        except Exception as e:
            self.log_message.emit(f"Error: {str(e)}", "error")
            QMessageBox.critical(self, "Error", f"Failed to add publication:\n{str(e)}")
    
    def _load_preprints(self):
        """Load and display preprints."""
        if not self._pub_manager:
            QMessageBox.warning(self, "Error", "Please login first.")
            return
        
        self.preprints_list.clear()
        preprints = self._pub_manager.get_preprints()
        
        if not preprints:
            self.log_message.emit("No preprints found", "info")
            return
        
        self.log_message.emit(f"Loaded {len(preprints)} preprints", "success")
        
        for pub in preprints:
            item = QListWidgetItem(pub.title)
            item.setData(Qt.UserRole, pub)
            self.preprints_list.addItem(item)
    
    def _mark_as_published(self):
        """Mark selected preprint as published."""
        if not self._pub_manager:
            return
        
        current = self.preprints_list.currentItem()
        if not current:
            QMessageBox.warning(self, "No Selection", "Please select a preprint first.")
            return
        
        pub = current.data(Qt.UserRole)
        
        dialog = PublishDialog(pub.title, self)
        if dialog.exec_() == QDialog.Accepted:
            doi = dialog.get_doi()
            if not doi:
                QMessageBox.warning(self, "Missing DOI", "Please enter a DOI.")
                return
            
            try:
                success = self._pub_manager.update_preprint_to_published(pub.title, doi)
                if success:
                    self.log_message.emit(f"Marked as published: {pub.title[:30]}...", "success")
                    self._load_preprints()  # Refresh
                else:
                    raise Exception("Failed to update")
            except Exception as e:
                self.log_message.emit(f"Error: {str(e)}", "error")
                QMessageBox.critical(self, "Error", f"Failed to update:\n{str(e)}")
    
    def _open_pictures_folder(self):
        """Open the publications pictures folder."""
        if self._pub_manager:
            open_in_file_explorer(self._pub_manager.pictures_dir)
            self.log_message.emit("Opened publications pictures folder", "info")
    
    def _open_publications_file(self):
        """Open the publications.yml file in editor."""
        if self._pub_manager:
            path = self._pub_manager.get_publications_file_path()
            if os.path.exists(path):
                open_file_in_editor(path)
                self.log_message.emit("Opened publications.yml", "info")
