"""
Drag and drop area widget for images.
"""

import os

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QDragEnterEvent, QDropEvent, QPixmap
from PyQt5.QtWidgets import (QFileDialog, QFrame, QLabel, QPushButton,
                             QVBoxLayout)


class DragDropArea(QFrame):
    """
    A drag-and-drop area for image files.
    Supports both drag-drop and click-to-browse.
    """
    
    # Signal emitted when a file is dropped or selected
    file_dropped = pyqtSignal(str)  # Emits the file path
    
    SUPPORTED_FORMATS = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'}
    
    def __init__(self, parent=None, placeholder_text: str = "Drag & drop an image here"):
        super().__init__(parent)
        self.setObjectName("dropArea")
        self._file_path = None
        self._placeholder_text = placeholder_text
        self._setup_ui()
        self.setAcceptDrops(True)
    
    def _setup_ui(self):
        """Set up the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)
        layout.setAlignment(Qt.AlignCenter)
        
        # Preview label (for showing image thumbnail)
        self.preview_label = QLabel()
        self.preview_label.setAlignment(Qt.AlignCenter)
        self.preview_label.setMinimumSize(120, 120)
        self.preview_label.setMaximumSize(200, 200)
        self.preview_label.setScaledContents(False)
        self.preview_label.hide()
        layout.addWidget(self.preview_label)
        
        # Icon/placeholder
        self.icon_label = QLabel("🖼️")
        self.icon_label.setStyleSheet("font-size: 32px;")
        self.icon_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.icon_label)
        
        # Text label
        self.text_label = QLabel(self._placeholder_text)
        self.text_label.setStyleSheet("""
            QLabel {
                color: #6c757d;
                font-size: 13px;
            }
        """)
        self.text_label.setAlignment(Qt.AlignCenter)
        self.text_label.setWordWrap(True)
        layout.addWidget(self.text_label)
        
        # Browse button
        self.browse_btn = QPushButton("Browse Files")
        self.browse_btn.setObjectName("secondaryButton")
        self.browse_btn.setMaximumWidth(120)
        self.browse_btn.clicked.connect(self._browse_file)
        layout.addWidget(self.browse_btn, alignment=Qt.AlignCenter)
        
        # Clear button (hidden by default)
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.setObjectName("smallButton")
        self.clear_btn.setStyleSheet("""
            QPushButton {
                background-color: #e9ecef;
                color: #495057;
                border: 1px solid #dee2e6;
            }
            QPushButton:hover {
                background-color: #dee2e6;
            }
        """)
        self.clear_btn.setMaximumWidth(80)
        self.clear_btn.clicked.connect(self.clear)
        self.clear_btn.hide()
        layout.addWidget(self.clear_btn, alignment=Qt.AlignCenter)
        
        # File name label
        self.filename_label = QLabel()
        self.filename_label.setStyleSheet("""
            QLabel {
                color: #4361ee;
                font-size: 12px;
            }
        """)
        self.filename_label.setAlignment(Qt.AlignCenter)
        self.filename_label.setWordWrap(True)
        self.filename_label.hide()
        layout.addWidget(self.filename_label)
        
        self.setMinimumHeight(180)
    
    def dragEnterEvent(self, event: QDragEnterEvent):
        """Handle drag enter event."""
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if urls and self._is_valid_image(urls[0].toLocalFile()):
                event.acceptProposedAction()
                self.setObjectName("dropAreaActive")
                self.style().unpolish(self)
                self.style().polish(self)
    
    def dragLeaveEvent(self, event):
        """Handle drag leave event."""
        self.setObjectName("dropArea")
        self.style().unpolish(self)
        self.style().polish(self)
    
    def dropEvent(self, event: QDropEvent):
        """Handle drop event."""
        self.setObjectName("dropArea")
        self.style().unpolish(self)
        self.style().polish(self)
        
        urls = event.mimeData().urls()
        if urls:
            file_path = urls[0].toLocalFile()
            if self._is_valid_image(file_path):
                self._set_file(file_path)
    
    def _is_valid_image(self, file_path: str) -> bool:
        """Check if the file is a valid image."""
        if not file_path:
            return False
        ext = os.path.splitext(file_path)[1].lower()
        return ext in self.SUPPORTED_FORMATS
    
    def _browse_file(self):
        """Open file browser dialog."""
        file_filter = "Images (*.jpg *.jpeg *.png *.gif *.webp *.bmp)"
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Image", "", file_filter
        )
        if file_path:
            self._set_file(file_path)
    
    def _set_file(self, file_path: str):
        """Set the selected file and update display."""
        self._file_path = file_path
        filename = os.path.basename(file_path)
        
        # Show thumbnail
        pixmap = QPixmap(file_path)
        if not pixmap.isNull():
            scaled = pixmap.scaled(
                180, 180, 
                Qt.KeepAspectRatio, 
                Qt.SmoothTransformation
            )
            self.preview_label.setPixmap(scaled)
            self.preview_label.show()
            self.icon_label.hide()
        
        # Update labels
        self.text_label.setText("Image selected")
        self.filename_label.setText(filename)
        self.filename_label.show()
        self.clear_btn.show()
        
        # Emit signal
        self.file_dropped.emit(file_path)
    
    def clear(self):
        """Clear the selected file."""
        self._file_path = None
        self.preview_label.clear()
        self.preview_label.hide()
        self.icon_label.show()
        self.text_label.setText(self._placeholder_text)
        self.filename_label.hide()
        self.clear_btn.hide()
    
    def get_file_path(self) -> str:
        """Get the currently selected file path."""
        return self._file_path
    
    def has_file(self) -> bool:
        """Check if a file is currently selected."""
        return self._file_path is not None
    
    def set_placeholder_text(self, text: str):
        """Set the placeholder text."""
        self._placeholder_text = text
        if not self._file_path:
            self.text_label.setText(text)
