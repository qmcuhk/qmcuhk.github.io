"""
Log panel widget for displaying application logs.
"""

from datetime import datetime

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QTextCursor
from PyQt5.QtWidgets import QFrame, QLabel, QTextEdit, QVBoxLayout, QWidget


class LogPanel(QFrame):
    """
    A widget for displaying application logs.
    Dark themed text area with timestamp-prefixed messages.
    """
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("logPanel")
        self._setup_ui()
    
    def _setup_ui(self):
        """Set up the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)
        
        # Title
        title = QLabel("Activity Log")
        title.setStyleSheet("""
            QLabel {
                color: #a0a0a0;
                font-size: 11px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
        """)
        layout.addWidget(title)
        
        # Log text area
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Menlo, Monaco, Consolas, monospace", 11))
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #1a1a2e;
                color: #e0e0e0;
                border: none;
                border-radius: 4px;
                padding: 8px;
            }
            QScrollBar:vertical {
                background-color: #2d2d44;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background-color: #4a4a6a;
                border-radius: 4px;
                min-height: 30px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0;
            }
        """)
        layout.addWidget(self.log_text)
        
        self.setMinimumHeight(150)
    
    def log(self, message: str, level: str = "info"):
        """
        Add a log message.
        
        Args:
            message: The message to log
            level: Log level ('info', 'success', 'warning', 'error')
        """
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        # Color based on level
        colors = {
            'info': '#a0a0a0',
            'success': '#4ade80',
            'warning': '#fbbf24',
            'error': '#f87171',
        }
        color = colors.get(level, colors['info'])
        
        # Level prefix
        prefixes = {
            'info': 'ℹ',
            'success': '✓',
            'warning': '⚠',
            'error': '✗',
        }
        prefix = prefixes.get(level, '•')
        
        # Format message
        html = f'<span style="color: #6b7280;">[{timestamp}]</span> '
        html += f'<span style="color: {color};">{prefix} {message}</span>'
        
        self.log_text.append(html)
        
        # Scroll to bottom
        cursor = self.log_text.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.log_text.setTextCursor(cursor)
    
    def log_info(self, message: str):
        """Log an info message."""
        self.log(message, "info")
    
    def log_success(self, message: str):
        """Log a success message."""
        self.log(message, "success")
    
    def log_warning(self, message: str):
        """Log a warning message."""
        self.log(message, "warning")
    
    def log_error(self, message: str):
        """Log an error message."""
        self.log(message, "error")
    
    def clear(self):
        """Clear all log messages."""
        self.log_text.clear()
