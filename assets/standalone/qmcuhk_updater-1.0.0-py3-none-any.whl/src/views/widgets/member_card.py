"""
Member card widget for displaying member information.
"""

import os

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QCursor, QPixmap
from PyQt5.QtWidgets import (QFrame, QHBoxLayout, QLabel, QSizePolicy,
                             QVBoxLayout)


class MemberCard(QFrame):
    """
    A clickable card displaying member photo, name, and ordering number.
    """
    
    # Signal emitted when the card is clicked
    clicked = pyqtSignal(str)  # Emits the member file path
    
    def __init__(self, name: str, photo_path: str = None, 
                 ordering: int = 0, file_path: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("memberCard")
        self._file_path = file_path
        self._name = name
        self._ordering = ordering
        self._setup_ui(name, photo_path, ordering)
        self.setCursor(QCursor(Qt.PointingHandCursor))
    
    def _setup_ui(self, name: str, photo_path: str, ordering: int):
        """Set up the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        
        # Ordering number (top left)
        order_layout = QHBoxLayout()
        self.order_label = QLabel(f"#{ordering}")
        self.order_label.setStyleSheet("""
            QLabel {
                background-color: #e9ecef;
                color: #495057;
                font-size: 10px;
                font-weight: 600;
                padding: 2px 6px;
                border-radius: 10px;
            }
        """)
        order_layout.addWidget(self.order_label)
        order_layout.addStretch()
        layout.addLayout(order_layout)
        
        # Photo
        self.photo_label = QLabel()
        self.photo_label.setAlignment(Qt.AlignCenter)
        self.photo_label.setFixedSize(100, 100)
        self.photo_label.setStyleSheet("""
            QLabel {
                background-color: #e9ecef;
                border-radius: 50px;
            }
        """)
        
        if photo_path and os.path.exists(photo_path):
            pixmap = QPixmap(photo_path)
            if not pixmap.isNull():
                # Create circular mask effect via scaled square
                scaled = pixmap.scaled(
                    100, 100,
                    Qt.KeepAspectRatioByExpanding,
                    Qt.SmoothTransformation
                )
                # Crop to center
                if scaled.width() > 100:
                    x = (scaled.width() - 100) // 2
                    scaled = scaled.copy(x, 0, 100, 100)
                if scaled.height() > 100:
                    y = (scaled.height() - 100) // 2
                    scaled = scaled.copy(0, y, 100, 100)
                self.photo_label.setPixmap(scaled)
        else:
            # Default avatar
            self.photo_label.setText("👤")
            self.photo_label.setStyleSheet("""
                QLabel {
                    background-color: #e9ecef;
                    border-radius: 50px;
                    font-size: 40px;
                }
            """)
        
        layout.addWidget(self.photo_label, alignment=Qt.AlignCenter)
        
        # Name
        self.name_label = QLabel(name)
        self.name_label.setAlignment(Qt.AlignCenter)
        self.name_label.setWordWrap(True)
        self.name_label.setStyleSheet("""
            QLabel {
                font-size: 12px;
                font-weight: 500;
                color: #1a1a2e;
            }
        """)
        layout.addWidget(self.name_label)
        
        # Click hint
        hint_label = QLabel("Click to edit")
        hint_label.setAlignment(Qt.AlignCenter)
        hint_label.setStyleSheet("""
            QLabel {
                font-size: 10px;
                color: #6c757d;
            }
        """)
        layout.addWidget(hint_label)
        
        self.setFixedSize(120, 175)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
    
    def mousePressEvent(self, event):
        """Handle mouse press event."""
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self._file_path)
        super().mousePressEvent(event)
    
    def get_file_path(self) -> str:
        """Get the member file path."""
        return self._file_path
    
    def get_name(self) -> str:
        """Get the member name."""
        return self._name
    
    def get_ordering(self) -> int:
        """Get the member ordering number."""
        return self._ordering
