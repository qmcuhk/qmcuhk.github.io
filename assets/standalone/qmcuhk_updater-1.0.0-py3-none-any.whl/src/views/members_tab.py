"""
Members tab for adding and editing group members.
"""

import os

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (QFormLayout, QFrame, QGridLayout, QHBoxLayout,
                             QInputDialog, QLabel, QLineEdit, QMessageBox,
                             QPushButton, QScrollArea, QSplitter, QVBoxLayout,
                             QWidget)

from ..domain.member import Member, MemberManager
from ..utils.file_utils import (get_file_extension, open_file_in_editor,
                                open_in_file_explorer, sanitize_filename)
from .widgets.drag_drop_area import DragDropArea
from .widgets.member_card import MemberCard


class MembersTab(QWidget):
    """
    Tab for managing group members.
    Left panel (2/3): Form for adding new members
    Right panel (1/3): Display existing members
    """
    
    # Signal for logging
    log_message = pyqtSignal(str, str)  # message, level
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._root_folder = None
        self._member_manager = None
        self._setup_ui()
    
    def _setup_ui(self):
        """Set up the UI components."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        
        # Left panel - Form
        left_panel = QWidget()
        self._setup_left_panel(left_panel)
        splitter.addWidget(left_panel)
        
        # Right panel - Existing members
        right_panel = QWidget()
        self._setup_right_panel(right_panel)
        splitter.addWidget(right_panel)
        
        # Set initial sizes (2:1 ratio)
        splitter.setSizes([600, 300])
        
        layout.addWidget(splitter)
    
    def _setup_left_panel(self, panel: QWidget):
        """Set up the left panel with the member form."""
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(16)
        
        # Header with folder button
        header_layout = QHBoxLayout()
        title = QLabel("Add New Member")
        title.setObjectName("sectionTitle")
        header_layout.addWidget(title)
        header_layout.addStretch()
        
        # Open folder button
        folder_btn = QPushButton("📁")
        folder_btn.setObjectName("iconButton")
        folder_btn.setToolTip("Open members folder")
        folder_btn.clicked.connect(self._open_members_folder)
        header_layout.addWidget(folder_btn)
        
        # Open images folder button
        img_folder_btn = QPushButton("🖼️")
        img_folder_btn.setObjectName("iconButton")
        img_folder_btn.setToolTip("Open member photos folder")
        img_folder_btn.clicked.connect(self._open_photos_folder)
        header_layout.addWidget(img_folder_btn)
        
        layout.addLayout(header_layout)
        
        # Scroll area for the form
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        
        form_container = QWidget()
        form_layout = QVBoxLayout(form_container)
        form_layout.setSpacing(12)
        
        # Form fields
        self.form = QFormLayout()
        self.form.setSpacing(12)
        self.form.setLabelAlignment(Qt.AlignRight)
        self.form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        
        # Name
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Full Name")
        self.name_input.setMinimumWidth(300)
        self.form.addRow("Name:", self.name_input)
        
        # Title
        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("PhD Student, Undergraduate Student...")
        self.form.addRow("Title:", self.title_input)
        
        # Affiliation 1
        self.affiliation1_input = QLineEdit()
        self.affiliation1_input.setText("The Chinese University of HK")
        self.form.addRow("Affiliation 1:", self.affiliation1_input)
        
        # Affiliation 2
        self.affiliation2_input = QLineEdit()
        self.form.addRow("Affiliation 2:", self.affiliation2_input)
        
        # Email
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("jane.doe@link.cuhk.edu.hk")
        self.form.addRow("Email:", self.email_input)
        
        # Start date
        self.start_date_input = QLineEdit()
        self.start_date_input.setPlaceholderText("2024-09-01")
        self.form.addRow("Start Date:", self.start_date_input)
        
        # Ordering
        self.ordering_input = QLineEdit()
        self.ordering_input.setPlaceholderText("10")
        self.form.addRow("Ordering:", self.ordering_input)
        
        form_layout.addLayout(self.form)
        
        # Photo drop area
        photo_label = QLabel("Member Photo:")
        photo_label.setStyleSheet("font-weight: 500; margin-top: 8px;")
        form_layout.addWidget(photo_label)
        
        self.photo_drop = DragDropArea(
            placeholder_text="Drag & drop member photo here\n(will be renamed based on name)"
        )
        self.photo_drop.file_dropped.connect(self._on_photo_dropped)
        form_layout.addWidget(self.photo_drop)
        
        # Photo filename preview
        self.photo_preview_label = QLabel()
        self.photo_preview_label.setStyleSheet("color: #6c757d; font-size: 12px;")
        self.photo_preview_label.hide()
        form_layout.addWidget(self.photo_preview_label)
        
        form_layout.addStretch()
        
        scroll.setWidget(form_container)
        layout.addWidget(scroll)
        
        # Bottom buttons
        btn_layout = QHBoxLayout()
        
        # Gear button to open member file
        self.gear_btn = QPushButton("⚙️ Edit in Editor")
        self.gear_btn.setObjectName("secondaryButton")
        self.gear_btn.clicked.connect(self._open_member_template)
        self.gear_btn.setEnabled(False)
        btn_layout.addWidget(self.gear_btn)
        
        btn_layout.addStretch()
        
        # Clear button
        clear_btn = QPushButton("Clear")
        clear_btn.setObjectName("secondaryButton")
        clear_btn.clicked.connect(self._clear_form)
        btn_layout.addWidget(clear_btn)
        
        # Submit button
        self.submit_btn = QPushButton("Submit")
        self.submit_btn.clicked.connect(self._submit_member)
        btn_layout.addWidget(self.submit_btn)
        
        layout.addLayout(btn_layout)
    
    def _setup_right_panel(self, panel: QWidget):
        """Set up the right panel with existing members."""
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)
        
        # Header
        title = QLabel("Existing Members")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)
        
        # Load button
        self.load_members_btn = QPushButton("Load Existing Members")
        self.load_members_btn.clicked.connect(self._load_members)
        layout.addWidget(self.load_members_btn)
        
        # Info label
        info_label = QLabel("Click a member card to open their file in the text editor")
        info_label.setStyleSheet("color: #6c757d; font-size: 11px;")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        # Scroll area for member cards
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        
        self.members_container = QWidget()
        self.members_layout = QGridLayout(self.members_container)
        self.members_layout.setSpacing(12)
        self.members_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        
        scroll.setWidget(self.members_container)
        layout.addWidget(scroll)
    
    def set_root_folder(self, root_folder: str):
        """Set the website root folder."""
        self._root_folder = root_folder
        self._member_manager = MemberManager(root_folder)
        self._clear_members_display()
    
    def _on_photo_dropped(self, file_path: str):
        """Handle photo file dropped."""
        name = self.name_input.text().strip()
        if name:
            ext = get_file_extension(file_path)
            new_name = sanitize_filename(name) + ext
            self.photo_preview_label.setText(f"Will be saved as: {new_name}")
            self.photo_preview_label.show()
        else:
            self.photo_preview_label.setText("Enter name first to see filename preview")
            self.photo_preview_label.show()
    
    def _clear_form(self):
        """Clear all form fields."""
        self.name_input.clear()
        self.title_input.clear()
        self.affiliation1_input.setText("The Chinese University of HK")
        self.affiliation2_input.clear()
        self.email_input.clear()
        self.start_date_input.clear()
        self.ordering_input.clear()
        self.photo_drop.clear()
        self.photo_preview_label.hide()
        self.gear_btn.setEnabled(False)
    
    def _submit_member(self):
        """Submit the new member."""
        if not self._member_manager:
            QMessageBox.warning(self, "Error", "Please login first.")
            return
        
        # Get name (optional, but needed for filename if provided)
        name = self.name_input.text().strip()
        if not name:
            name = "new_member"
        
        # Check for photo
        photo_path = self.photo_drop.get_file_path()
        if photo_path:
            # Check if photo already exists
            ext = get_file_extension(photo_path)
            photo_filename = sanitize_filename(name) + ext
            
            if self._member_manager.check_photo_exists(photo_filename):
                new_name, ok = QInputDialog.getText(
                    self,
                    "File Exists",
                    f"Photo '{photo_filename}' already exists.\nEnter a new filename (without extension):",
                    text=sanitize_filename(name) + "_new"
                )
                if not ok or not new_name:
                    return
                photo_filename = new_name.strip() + ext
        
        # Create member object
        try:
            ordering = int(self.ordering_input.text().strip()) if self.ordering_input.text().strip() else 10
        except ValueError:
            ordering = 10
        
        member = Member(
            name=name if name != "new_member" else "",
            title=self.title_input.text().strip(),
            affiliation_1=self.affiliation1_input.text().strip(),
            affiliation_2=self.affiliation2_input.text().strip(),
            email=self.email_input.text().strip(),
            start_date=self.start_date_input.text().strip(),
            ordering=ordering,
        )
        
        # If photo filename was changed, update it
        if photo_path and 'photo_filename' in dir():
            member.photo_path = photo_filename
        
        try:
            file_path = self._member_manager.create_member(member, photo_path)
            self.log_message.emit(f"Created member: {name}", "success")
            self.log_message.emit(f"File: {os.path.basename(file_path)}", "info")
            
            QMessageBox.information(
                self,
                "Success",
                f"Member '{name}' created successfully!\n\nFile: {file_path}"
            )
            
            self._clear_form()
            
        except Exception as e:
            self.log_message.emit(f"Error creating member: {str(e)}", "error")
            QMessageBox.critical(self, "Error", f"Failed to create member:\n{str(e)}")
    
    def _load_members(self):
        """Load and display existing members."""
        if not self._member_manager:
            QMessageBox.warning(self, "Error", "Please login first.")
            return
        
        self._clear_members_display()
        
        members = self._member_manager.get_all_members()
        
        # Filter out inactive members (ordering == -1)
        active_members = [m for m in members if m.ordering != -1]
        
        if not active_members:
            self.log_message.emit("No active members found", "info")
            return
        
        self.log_message.emit(f"Loaded {len(active_members)} active members", "success")
        
        # Display member cards in a grid (2 columns)
        row = 0
        col = 0
        for member in active_members:
            photo_path = self._member_manager.get_member_photo_path(member)
            card = MemberCard(
                name=member.name,
                photo_path=photo_path,
                ordering=member.ordering,
                file_path=member.file_path
            )
            card.clicked.connect(self._on_member_card_clicked)
            self.members_layout.addWidget(card, row, col)
            
            col += 1
            if col >= 2:
                col = 0
                row += 1
    
    def _clear_members_display(self):
        """Clear the members display."""
        while self.members_layout.count():
            item = self.members_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
    
    def _on_member_card_clicked(self, file_path: str):
        """Handle member card click."""
        if file_path and os.path.exists(file_path):
            self.log_message.emit(f"Opening: {os.path.basename(file_path)}", "info")
            open_file_in_editor(file_path)
    
    def _open_members_folder(self):
        """Open the members folder in file explorer."""
        if self._member_manager:
            open_in_file_explorer(self._member_manager.members_dir)
            self.log_message.emit("Opened members folder", "info")
    
    def _open_photos_folder(self):
        """Open the photos folder in file explorer."""
        if self._member_manager:
            open_in_file_explorer(self._member_manager.photos_dir)
            self.log_message.emit("Opened photos folder", "info")
    
    def _open_member_template(self):
        """Open member template or last created file."""
        # This would open a template file if available
        pass
