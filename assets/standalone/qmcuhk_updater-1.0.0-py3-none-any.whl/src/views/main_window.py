"""
Main window for the QMCUHK Website Updater application.
"""

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QFrame, QHBoxLayout, QLabel, QMainWindow,
                             QSplitter, QTabWidget, QVBoxLayout, QWidget)

from ..domain.user import User, UserManager
from ..utils.styles import LIGHT_THEME
from .login_panel import LoginPanel
from .members_tab import MembersTab
from .news_tab import NewsTab
from .openings_tab import OpeningsTab
from .publications_tab import PublicationsTab
from .teaching_tab import TeachingTab
from .widgets.log_panel import LogPanel


class MainWindow(QMainWindow):
    """
    Main application window.
    Layout: Left panel (user info + logs) | Tab container
    Login panel at top (moves to bottom when logged in)
    """
    
    def __init__(self):
        super().__init__()
        self.user_manager = UserManager()
        self._current_user = None
        self._setup_ui()
        self._apply_styles()
    
    def _setup_ui(self):
        """Set up the main UI layout."""
        self.setWindowTitle("QMCUHK Website Updater")
        self.setMinimumSize(1100, 700)
        
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Login panel (at top initially)
        self.login_panel = LoginPanel(self.user_manager)
        self.login_panel.user_logged_in.connect(self._on_user_logged_in)
        self.login_panel.user_logged_out.connect(self._on_user_logged_out)
        main_layout.addWidget(self.login_panel)
        
        # Main content area (hidden until login)
        self.content_widget = QWidget()
        self._setup_content_area()
        self.content_widget.hide()
        main_layout.addWidget(self.content_widget, 1)
    
    def _setup_content_area(self):
        """Set up the main content area with left panel and tabs."""
        layout = QHBoxLayout(self.content_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Create splitter for resizable panels
        splitter = QSplitter(Qt.Horizontal)
        
        # Left panel
        left_panel = QFrame()
        left_panel.setObjectName("leftPanel")
        left_panel.setMinimumWidth(220)
        left_panel.setMaximumWidth(300)
        self._setup_left_panel(left_panel)
        splitter.addWidget(left_panel)
        
        # Right side - Tab widget
        self.tab_widget = QTabWidget()
        self._setup_tabs()
        splitter.addWidget(self.tab_widget)
        
        # Set initial sizes
        splitter.setSizes([250, 850])
        
        layout.addWidget(splitter)
    
    def _setup_left_panel(self, panel: QFrame):
        """Set up the left panel with user info and log panel."""
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(12, 16, 12, 16)
        layout.setSpacing(16)
        
        # App title
        app_title = QLabel("QMCUHK")
        app_title.setStyleSheet("""
            QLabel {
                font-size: 20px;
                font-weight: 700;
                color: #4361ee;
            }
        """)
        layout.addWidget(app_title)
        
        subtitle = QLabel("Website Updater")
        subtitle.setStyleSheet("""
            QLabel {
                font-size: 12px;
                color: #6c757d;
                margin-top: -8px;
            }
        """)
        layout.addWidget(subtitle)
        
        # Separator
        sep = QFrame()
        sep.setFrameShape(QFrame.HLine)
        sep.setStyleSheet("background-color: #dee2e6;")
        layout.addWidget(sep)
        
        # User section
        user_title = QLabel("Current User")
        user_title.setStyleSheet("""
            QLabel {
                font-size: 11px;
                font-weight: 600;
                color: #6c757d;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
        """)
        layout.addWidget(user_title)
        
        self.user_name_label = QLabel("Not logged in")
        self.user_name_label.setObjectName("userNameLabel")
        self.user_name_label.setWordWrap(True)
        layout.addWidget(self.user_name_label)
        
        self.user_folder_label = QLabel()
        self.user_folder_label.setStyleSheet("""
            QLabel {
                font-size: 11px;
                color: #6c757d;
            }
        """)
        self.user_folder_label.setWordWrap(True)
        self.user_folder_label.hide()
        layout.addWidget(self.user_folder_label)
        
        layout.addStretch()
        
        # Log panel
        self.log_panel = LogPanel()
        self.log_panel.setMinimumHeight(200)
        layout.addWidget(self.log_panel, 1)
    
    def _setup_tabs(self):
        """Set up the tab widget with all tabs."""
        # Members tab
        self.members_tab = MembersTab()
        self.members_tab.log_message.connect(self._log)
        self.tab_widget.addTab(self.members_tab, "👥 Members")
        
        # Publications tab
        self.publications_tab = PublicationsTab()
        self.publications_tab.log_message.connect(self._log)
        self.tab_widget.addTab(self.publications_tab, "📄 Publications")
        
        # Openings tab
        self.openings_tab = OpeningsTab()
        self.openings_tab.log_message.connect(self._log)
        self.tab_widget.addTab(self.openings_tab, "📋 Openings")
        
        # News tab
        self.news_tab = NewsTab()
        self.news_tab.log_message.connect(self._log)
        self.tab_widget.addTab(self.news_tab, "📰 News")
        
        # Teaching tab
        self.teaching_tab = TeachingTab()
        self.teaching_tab.log_message.connect(self._log)
        self.tab_widget.addTab(self.teaching_tab, "📚 Teaching")
    
    def _apply_styles(self):
        """Apply the application stylesheet."""
        self.setStyleSheet(LIGHT_THEME)
    
    def _on_user_logged_in(self, user: User):
        """Handle user login."""
        self._current_user = user
        
        # Update user display
        self.user_name_label.setText(user.username)
        self.user_folder_label.setText(f"📁 {user.root_folder}")
        self.user_folder_label.show()
        
        # Set root folder for all tabs
        self.members_tab.set_root_folder(user.root_folder)
        self.publications_tab.set_root_folder(user.root_folder)
        self.news_tab.set_root_folder(user.root_folder)
        self.openings_tab.set_root_folder(user.root_folder)
        self.teaching_tab.set_root_folder(user.root_folder)
        
        # Show content, move login panel to bottom
        self.content_widget.show()
        
        # Rearrange layout - login at bottom
        main_layout = self.centralWidget().layout()
        main_layout.removeWidget(self.login_panel)
        main_layout.addWidget(self.login_panel)
        
        self._log(f"Logged in as: {user.username}", "success")
        self._log(f"Website folder: {user.root_folder}", "info")
    
    def _on_user_logged_out(self):
        """Handle user logout."""
        self._current_user = None
        
        # Update user display
        self.user_name_label.setText("Not logged in")
        self.user_folder_label.hide()
        
        # Hide content, move login panel to top
        self.content_widget.hide()
        
        # Rearrange layout - login at top
        main_layout = self.centralWidget().layout()
        main_layout.removeWidget(self.login_panel)
        main_layout.insertWidget(0, self.login_panel)
        
        self._log("Logged out", "info")
    
    def _log(self, message: str, level: str = "info"):
        """Log a message to the log panel."""
        if level == "success":
            self.log_panel.log_success(message)
        elif level == "warning":
            self.log_panel.log_warning(message)
        elif level == "error":
            self.log_panel.log_error(message)
        else:
            self.log_panel.log_info(message)
