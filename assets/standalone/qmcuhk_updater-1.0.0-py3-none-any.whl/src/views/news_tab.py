"""
News tab for adding and viewing news items.
"""

import os

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (QFormLayout, QFrame, QHBoxLayout, QInputDialog,
                             QLabel, QLineEdit, QListWidget, QListWidgetItem,
                             QMessageBox, QPushButton, QScrollArea, QSplitter,
                             QTextEdit, QVBoxLayout, QWidget)

from ..domain.news import News, NewsManager
from ..utils.file_utils import (get_file_extension, open_file_in_editor,
                                open_in_file_explorer)
from .widgets.drag_drop_area import DragDropArea


class NewsTab(QWidget):
    """
    Tab for managing news items.
    Left panel: Form for adding news
    Right panel: List of existing news items
    """
    
    log_message = pyqtSignal(str, str)
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._root_folder = None
        self._news_manager = None
        self._setup_ui()
    
    def _setup_ui(self):
        """Set up the UI components."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        splitter = QSplitter(Qt.Horizontal)
        
        # Left panel - Form
        left_panel = QWidget()
        self._setup_left_panel(left_panel)
        splitter.addWidget(left_panel)
        
        # Right panel - Existing news
        right_panel = QWidget()
        self._setup_right_panel(right_panel)
        splitter.addWidget(right_panel)
        
        splitter.setSizes([600, 300])
        layout.addWidget(splitter)
    
    def _setup_left_panel(self, panel: QWidget):
        """Set up the left panel with the news form."""
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(16)
        
        # Header
        header_layout = QHBoxLayout()
        title = QLabel("Add News")
        title.setObjectName("sectionTitle")
        header_layout.addWidget(title)
        header_layout.addStretch()
        
        # Open folder button
        folder_btn = QPushButton("📁")
        folder_btn.setObjectName("iconButton")
        folder_btn.setToolTip("Open news folder")
        folder_btn.clicked.connect(self._open_news_folder)
        header_layout.addWidget(folder_btn)
        
        # Open images folder button
        img_folder_btn = QPushButton("🖼️")
        img_folder_btn.setObjectName("iconButton")
        img_folder_btn.setToolTip("Open news pictures folder")
        img_folder_btn.clicked.connect(self._open_pictures_folder)
        header_layout.addWidget(img_folder_btn)
        
        layout.addLayout(header_layout)
        
        # Scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        
        form_container = QWidget()
        form_layout = QVBoxLayout(form_container)
        form_layout.setSpacing(12)
        
        # Form fields
        self.form = QFormLayout()
        self.form.setSpacing(12)
        self.form.setLabelAlignment(Qt.AlignRight)
        
        # Title
        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("new member joined the group")
        self.form.addRow("Title:", self.title_input)
        
        # Date
        self.date_input = QLineEdit()
        self.date_input.setPlaceholderText("2025-08-01")
        self.date_input.textChanged.connect(self._update_filename_preview)
        self.form.addRow("Date:", self.date_input)
        
        # One word description (slug)
        self.slug_input = QLineEdit()
        self.slug_input.setPlaceholderText("collaboration")
        self.slug_input.textChanged.connect(self._update_filename_preview)
        self.form.addRow("One-word description:", self.slug_input)
        
        form_layout.addLayout(self.form)
        
        # Content
        content_label = QLabel("Content:")
        content_label.setStyleSheet("font-weight: 500; margin-top: 8px;")
        form_layout.addWidget(content_label)
        
        self.content_input = QTextEdit()
        self.content_input.setPlaceholderText(
            "Write the news content here...\n\n"
            "You can use Markdown formatting."
        )
        self.content_input.setMinimumHeight(150)
        form_layout.addWidget(self.content_input)
        
        # Picture section
        pic_label = QLabel("News Picture:")
        pic_label.setStyleSheet("font-weight: 500; margin-top: 8px;")
        form_layout.addWidget(pic_label)
        
        self.picture_drop = DragDropArea(
            placeholder_text="Drag & drop news picture here\n(will be renamed based on date and description)"
        )
        self.picture_drop.file_dropped.connect(self._on_picture_dropped)
        form_layout.addWidget(self.picture_drop)
        
        # Filename preview
        self.filename_preview = QLabel()
        self.filename_preview.setStyleSheet("color: #6c757d; font-size: 12px;")
        self.filename_preview.hide()
        form_layout.addWidget(self.filename_preview)
        
        form_layout.addStretch()
        
        scroll.setWidget(form_container)
        layout.addWidget(scroll)
        
        # Bottom buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        clear_btn = QPushButton("Clear")
        clear_btn.setObjectName("secondaryButton")
        clear_btn.clicked.connect(self._clear_form)
        btn_layout.addWidget(clear_btn)
        
        self.submit_btn = QPushButton("Submit")
        self.submit_btn.clicked.connect(self._submit_news)
        btn_layout.addWidget(self.submit_btn)
        
        layout.addLayout(btn_layout)
    
    def _setup_right_panel(self, panel: QWidget):
        """Set up the right panel with existing news list."""
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)
        
        # Header
        title = QLabel("Existing News")
        title.setObjectName("sectionTitle")
        layout.addWidget(title)
        
        # Load button
        self.load_news_btn = QPushButton("Load Existing News")
        self.load_news_btn.clicked.connect(self._load_news)
        layout.addWidget(self.load_news_btn)
        
        # Info
        info = QLabel("Click on a news item to open it in the text editor")
        info.setStyleSheet("color: #6c757d; font-size: 11px;")
        info.setWordWrap(True)
        layout.addWidget(info)
        
        # News list
        self.news_list = QListWidget()
        self.news_list.setAlternatingRowColors(True)
        self.news_list.itemDoubleClicked.connect(self._on_news_item_clicked)
        layout.addWidget(self.news_list)
        
        # Open button
        self.open_btn = QPushButton("Open Selected")
        self.open_btn.setObjectName("secondaryButton")
        self.open_btn.clicked.connect(self._open_selected_news)
        layout.addWidget(self.open_btn)
    
    def set_root_folder(self, root_folder: str):
        """Set the website root folder."""
        self._root_folder = root_folder
        self._news_manager = NewsManager(root_folder)
        self.news_list.clear()
    
    def _update_filename_preview(self):
        """Update the filename preview based on date and slug."""
        date = self.date_input.text().strip()
        slug = self.slug_input.text().strip()
        
        if date and slug:
            date_parts = date.replace('-', '_')
            filename = f"news_{date_parts}_{slug}"
            self.filename_preview.setText(f"Filename: {filename}.md")
            self.filename_preview.show()
        else:
            self.filename_preview.hide()
    
    def _on_picture_dropped(self, file_path: str):
        """Handle picture file dropped."""
        self._update_filename_preview()
    
    def _clear_form(self):
        """Clear all form fields."""
        self.title_input.clear()
        self.date_input.clear()
        self.slug_input.clear()
        self.content_input.clear()
        self.picture_drop.clear()
        self.filename_preview.hide()
    
    def _submit_news(self):
        """Submit the new news item."""
        if not self._news_manager:
            QMessageBox.warning(self, "Error", "Please login first.")
            return
        
        # Validate required fields
        title = self.title_input.text().strip()
        date = self.date_input.text().strip()
        slug = self.slug_input.text().strip()
        content = self.content_input.toPlainText().strip()
        
        if not title:
            QMessageBox.warning(self, "Missing Information", "Please enter a title.")
            return
        
        if not date:
            QMessageBox.warning(self, "Missing Information", "Please enter a date.")
            return
        
        if not slug:
            QMessageBox.warning(self, "Missing Information", "Please enter a one-word description.")
            return
        
        # Validate date format
        import re
        if not re.match(r'^\d{4}-\d{2}-\d{2}$', date):
            QMessageBox.warning(
                self, 
                "Invalid Date", 
                "Please enter date in YYYY-MM-DD format (e.g., 2025-08-01)"
            )
            return
        
        # Create news object
        news = News(
            title=title,
            date=date,
            slug=slug,
            content=content,
        )
        
        # Check if file already exists
        if self._news_manager.check_news_file_exists(news):
            reply = QMessageBox.question(
                self,
                "File Exists",
                f"A news file with this date and description already exists.\n"
                f"Do you want to overwrite it?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply != QMessageBox.Yes:
                return
        
        # Check picture
        pic_path = self.picture_drop.get_file_path()
        if pic_path:
            ext = get_file_extension(pic_path)
            pic_filename = news.generate_picture_filename(ext)
            
            if self._news_manager.check_picture_exists(pic_filename):
                new_name, ok = QInputDialog.getText(
                    self,
                    "File Exists",
                    f"Picture '{pic_filename}' already exists.\n"
                    f"Enter a new filename (without extension):",
                    text=pic_filename.rsplit('.', 1)[0] + "_new"
                )
                if not ok or not new_name:
                    return
                # We'll need to handle this differently - for now just warn
        
        try:
            file_path = self._news_manager.create_news(news, pic_path)
            self.log_message.emit(f"Created news: {title[:30]}...", "success")
            self.log_message.emit(f"File: {os.path.basename(file_path)}", "info")
            
            QMessageBox.information(
                self,
                "Success",
                f"News created successfully!\n\nFile: {file_path}"
            )
            
            self._clear_form()
            
        except Exception as e:
            self.log_message.emit(f"Error creating news: {str(e)}", "error")
            QMessageBox.critical(self, "Error", f"Failed to create news:\n{str(e)}")
    
    def _load_news(self):
        """Load and display existing news items."""
        if not self._news_manager:
            QMessageBox.warning(self, "Error", "Please login first.")
            return
        
        self.news_list.clear()
        news_items = self._news_manager.get_all_news()
        
        if not news_items:
            self.log_message.emit("No news items found", "info")
            return
        
        self.log_message.emit(f"Loaded {len(news_items)} news items", "success")
        
        for news in news_items:
            display_text = f"[{news.date}] {news.title}"
            item = QListWidgetItem(display_text)
            item.setData(Qt.UserRole, news)
            self.news_list.addItem(item)
    
    def _on_news_item_clicked(self, item: QListWidgetItem):
        """Handle news item double-click."""
        news = item.data(Qt.UserRole)
        if news and news.file_path:
            self._open_news_file(news.file_path)
    
    def _open_selected_news(self):
        """Open the selected news item in editor."""
        current = self.news_list.currentItem()
        if not current:
            QMessageBox.warning(self, "No Selection", "Please select a news item first.")
            return
        
        news = current.data(Qt.UserRole)
        if news and news.file_path:
            self._open_news_file(news.file_path)
    
    def _open_news_file(self, file_path: str):
        """Open a news file in the editor."""
        if os.path.exists(file_path):
            self.log_message.emit(f"Opening: {os.path.basename(file_path)}", "info")
            open_file_in_editor(file_path)
    
    def _open_news_folder(self):
        """Open the news folder in file explorer."""
        if self._news_manager:
            open_in_file_explorer(self._news_manager.get_news_directory())
            self.log_message.emit("Opened news folder", "info")
    
    def _open_pictures_folder(self):
        """Open the news pictures folder in file explorer."""
        if self._news_manager:
            open_in_file_explorer(self._news_manager.get_pictures_directory())
            self.log_message.emit("Opened news pictures folder", "info")
