# Views layer - PyQt5 UI components
