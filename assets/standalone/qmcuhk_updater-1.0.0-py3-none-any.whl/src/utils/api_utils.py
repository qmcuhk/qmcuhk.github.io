"""
API utilities for fetching publication data from DOI and arXiv.
"""

import re
from dataclasses import dataclass
from typing import Any, Dict, Optional

import requests


@dataclass
class PublicationData:
    """Data structure for publication information."""
    title: str = ""
    authors: str = ""
    date: str = ""
    journal: str = ""
    doi: str = ""
    arxiv: str = ""
    is_preprint: bool = True


def parse_identifier(identifier: str) -> tuple[str, str]:
    """
    Parse an identifier string to determine if it's a DOI or arXiv ID.
    
    Returns:
        tuple: (type, cleaned_id) where type is 'doi', 'arxiv', or 'unknown'
    """
    identifier = identifier.strip()
    
    # Check for arXiv patterns
    # arXiv URL: https://arxiv.org/abs/2303.02865
    arxiv_url_match = re.search(r'arxiv\.org/abs/(\d{4}\.\d{4,5})', identifier, re.IGNORECASE)
    if arxiv_url_match:
        return ('arxiv', arxiv_url_match.group(1))
    
    # arXiv DOI: https://doi.org/10.48550/arXiv.2303.02865
    arxiv_doi_match = re.search(r'10\.48550/arXiv\.(\d{4}\.\d{4,5})', identifier, re.IGNORECASE)
    if arxiv_doi_match:
        return ('arxiv', arxiv_doi_match.group(1))
    
    # Plain arXiv ID: 2303.02865
    plain_arxiv_match = re.match(r'^(\d{4}\.\d{4,5})$', identifier)
    if plain_arxiv_match:
        return ('arxiv', plain_arxiv_match.group(1))
    
    # Old arXiv format: cond-mat/0001234
    old_arxiv_match = re.match(r'^([a-z\-]+/\d{7})$', identifier, re.IGNORECASE)
    if old_arxiv_match:
        return ('arxiv', old_arxiv_match.group(1))
    
    # Check for DOI patterns
    # DOI URL: https://doi.org/10.1103/PhysRevB.109.123456
    doi_url_match = re.search(r'doi\.org/(10\.\d{4,}/[^\s]+)', identifier)
    if doi_url_match:
        return ('doi', doi_url_match.group(1))
    
    # Plain DOI: 10.1103/PhysRevB.109.123456
    plain_doi_match = re.match(r'^(10\.\d{4,}/[^\s]+)$', identifier)
    if plain_doi_match:
        return ('doi', plain_doi_match.group(1))
    
    return ('unknown', identifier)


def fetch_arxiv_data(arxiv_id: str) -> Optional[PublicationData]:
    """
    Fetch publication data from arXiv API.
    
    Args:
        arxiv_id: The arXiv identifier (e.g., '2303.02865')
    
    Returns:
        PublicationData object or None if fetch failed
    """
    try:
        url = f"http://export.arxiv.org/api/query?id_list={arxiv_id}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        # Parse XML response
        content = response.text
        
        # Extract title from within <entry> block (skip the feed title)
        entry_start = content.find('<entry>')
        if entry_start == -1:
            return None
        entry_content = content[entry_start:]
        
        title_match = re.search(r'<title>([^<]+)</title>', entry_content)
        title = title_match.group(1).strip() if title_match else ""
        # Clean up title (remove newlines and extra spaces)
        title = ' '.join(title.split())
        
        # Extract authors
        authors = []
        for author_match in re.finditer(r'<author>\s*<name>([^<]+)</name>', content):
            authors.append(author_match.group(1).strip())
        authors_str = ", ".join(authors)
        
        # Extract published date
        published_match = re.search(r'<published>(\d{4}-\d{2}-\d{2})', content)
        date = published_match.group(1) if published_match else ""
        
        # Build arXiv URL
        arxiv_url = f"https://arxiv.org/abs/{arxiv_id}"
        doi_url = f"https://doi.org/10.48550/arXiv.{arxiv_id}"
        
        return PublicationData(
            title=title,
            authors=authors_str,
            date=date,
            journal=f"arXiv:{arxiv_id}",
            doi=doi_url,
            arxiv=arxiv_url,
            is_preprint=True
        )
        
    except requests.RequestException as e:
        print(f"Error fetching arXiv data: {e}")
        return None


def fetch_doi_data(doi: str) -> Optional[PublicationData]:
    """
    Fetch publication data from DOI using CrossRef API.
    
    Args:
        doi: The DOI string (e.g., '10.1103/PhysRevB.109.123456')
    
    Returns:
        PublicationData object or None if fetch failed
    """
    try:
        url = f"https://api.crossref.org/works/{doi}"
        headers = {
            'Accept': 'application/json',
            'User-Agent': 'QMCUHK-Updater/1.0 (mailto:maintainer@example.com)'
        }
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        data = response.json()
        work = data.get('message', {})
        
        # Extract title
        titles = work.get('title', [])
        title = titles[0] if titles else ""
        
        # Extract authors
        authors_list = work.get('author', [])
        authors = []
        for author in authors_list:
            given = author.get('given', '')
            family = author.get('family', '')
            if given and family:
                authors.append(f"{given} {family}")
            elif family:
                authors.append(family)
        authors_str = ", ".join(authors)
        
        # Extract date
        date_parts = work.get('published-print', work.get('published-online', {})).get('date-parts', [[]])
        if date_parts and date_parts[0]:
            parts = date_parts[0]
            if len(parts) >= 3:
                date = f"{parts[0]}-{parts[1]:02d}-{parts[2]:02d}"
            elif len(parts) >= 2:
                date = f"{parts[0]}-{parts[1]:02d}-01"
            elif len(parts) >= 1:
                date = f"{parts[0]}-01-01"
            else:
                date = ""
        else:
            date = ""
        
        # Extract journal
        container = work.get('container-title', [])
        journal = container[0] if container else ""
        
        # Add volume and page info if available
        volume = work.get('volume', '')
        page = work.get('page', '')
        if volume:
            journal = f"<b>{journal}</b> {volume}"
            if page:
                journal += f", {page}"
        
        # Check for arXiv link
        arxiv_url = ""
        links = work.get('link', [])
        for link in links:
            if 'arxiv' in link.get('URL', '').lower():
                arxiv_url = link['URL']
                break
        
        doi_url = f"https://doi.org/{doi}"
        
        return PublicationData(
            title=title,
            authors=authors_str,
            date=date,
            journal=journal,
            doi=doi_url,
            arxiv=arxiv_url,
            is_preprint=False
        )
        
    except requests.RequestException as e:
        print(f"Error fetching DOI data: {e}")
        return None


def fetch_publication_data(identifier: str) -> Optional[PublicationData]:
    """
    Fetch publication data from either DOI or arXiv based on the identifier.
    
    Args:
        identifier: DOI, DOI URL, arXiv ID, or arXiv URL
    
    Returns:
        PublicationData object or None if fetch failed
    """
    id_type, cleaned_id = parse_identifier(identifier)
    
    if id_type == 'arxiv':
        return fetch_arxiv_data(cleaned_id)
    elif id_type == 'doi':
        return fetch_doi_data(cleaned_id)
    else:
        # Try DOI first, then arXiv
        result = fetch_doi_data(identifier)
        if result:
            return result
        return fetch_arxiv_data(identifier)
