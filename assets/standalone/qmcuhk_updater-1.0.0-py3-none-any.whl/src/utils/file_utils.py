"""
File utility functions for the application.
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path


def open_in_file_explorer(path: str) -> bool:
    """
    Open the given path in the system file explorer.
    Returns True if successful, False otherwise.
    """
    path = os.path.abspath(path)
    
    if not os.path.exists(path):
        return False
    
    try:
        if sys.platform == 'darwin':  # macOS
            subprocess.run(['open', path], check=True)
        elif sys.platform == 'win32':  # Windows
            subprocess.run(['explorer', path], check=True)
        else:  # Linux
            subprocess.run(['xdg-open', path], check=True)
        return True
    except subprocess.CalledProcessError:
        return False


def open_file_in_editor(filepath: str) -> bool:
    """
    Open the given file in the system default text editor.
    Returns True if successful, False otherwise.
    """
    filepath = os.path.abspath(filepath)
    
    if not os.path.exists(filepath):
        return False
    
    try:
        if sys.platform == 'darwin':  # macOS
            subprocess.run(['open', filepath], check=True)
        elif sys.platform == 'win32':  # Windows
            os.startfile(filepath)
        else:  # Linux
            subprocess.run(['xdg-open', filepath], check=True)
        return True
    except (subprocess.CalledProcessError, AttributeError):
        return False


def copy_file_with_rename(src: str, dest_dir: str, new_name: str) -> str:
    """
    Copy a file to destination directory with a new name.
    Returns the full path of the copied file.
    """
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    
    dest_path = dest_dir / new_name
    shutil.copy2(src, dest_path)
    
    return str(dest_path)


def file_exists(filepath: str) -> bool:
    """Check if a file exists."""
    return os.path.isfile(filepath)


def ensure_directory(dirpath: str) -> None:
    """Ensure a directory exists, creating it if necessary."""
    Path(dirpath).mkdir(parents=True, exist_ok=True)


def get_file_extension(filepath: str) -> str:
    """Get the file extension including the dot."""
    return Path(filepath).suffix


def sanitize_filename(name: str) -> str:
    """
    Convert a name to a safe filename.
    - Lowercase
    - Replace spaces with underscores
    - Remove special characters
    """
    # Convert to lowercase and replace spaces
    name = name.lower().replace(' ', '_')
    
    # Remove special characters except underscores and hyphens
    safe_chars = set('abcdefghijklmnopqrstuvwxyz0123456789_-')
    name = ''.join(c for c in name if c in safe_chars)
    
    return name


def read_file_content(filepath: str) -> str:
    """Read and return the content of a file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()


def write_file_content(filepath: str, content: str) -> None:
    """Write content to a file."""
    ensure_directory(os.path.dirname(filepath))
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)


def list_files_in_directory(dirpath: str, extension: str = None) -> list:
    """
    List all files in a directory.
    Optionally filter by extension (e.g., '.md', '.yml').
    """
    dirpath = Path(dirpath)
    
    if not dirpath.exists():
        return []
    
    if extension:
        return [f for f in dirpath.iterdir() if f.is_file() and f.suffix == extension]
    
    return [f for f in dirpath.iterdir() if f.is_file()]


def get_image_files(dirpath: str) -> list:
    """Get all image files in a directory."""
    image_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'}
    dirpath = Path(dirpath)
    
    if not dirpath.exists():
        return []
    
    return [f for f in dirpath.iterdir() 
            if f.is_file() and f.suffix.lower() in image_extensions]
