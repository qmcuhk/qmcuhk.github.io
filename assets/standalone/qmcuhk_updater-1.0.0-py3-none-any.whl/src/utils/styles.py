"""
Modern light theme QSS styles for the application.
"""

LIGHT_THEME = """
/* Global styles */
QWidget {
    font-family: "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
    color: #1a1a2e;
    background-color: #f8f9fa;
}

/* Main window */
QMainWindow {
    background-color: #f8f9fa;
}

/* Labels */
QLabel {
    color: #1a1a2e;
    background-color: transparent;
}

QLabel#sectionTitle {
    font-size: 16px;
    font-weight: 600;
    color: #1a1a2e;
    padding: 8px 0;
}

QLabel#userNameLabel {
    font-size: 14px;
    font-weight: 500;
    color: #4361ee;
}

/* Buttons */
QPushButton {
    background-color: #4361ee;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 500;
    min-height: 32px;
}

QPushButton:hover {
    background-color: #3a56d4;
}

QPushButton:pressed {
    background-color: #2e47b0;
}

QPushButton:disabled {
    background-color: #c4c4c4;
    color: #888888;
}

QPushButton#secondaryButton {
    background-color: #e9ecef;
    color: #495057;
    border: 1px solid #dee2e6;
}

QPushButton#secondaryButton:hover {
    background-color: #dee2e6;
}

QPushButton#dangerButton {
    background-color: #dc3545;
}

QPushButton#dangerButton:hover {
    background-color: #c82333;
}

QPushButton#smallButton {
    padding: 4px 8px;
    min-height: 24px;
    font-size: 12px;
}

QPushButton#iconButton {
    background-color: transparent;
    border: 1px solid #dee2e6;
    border-radius: 4px;
    padding: 4px;
    min-width: 28px;
    min-height: 28px;
    max-width: 28px;
    max-height: 28px;
}

QPushButton#iconButton:hover {
    background-color: #e9ecef;
}

/* Line edits */
QLineEdit {
    background-color: white;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    padding: 8px 12px;
    min-height: 20px;
    selection-background-color: #4361ee;
}

QLineEdit:focus {
    border: 2px solid #4361ee;
    padding: 7px 11px;
}

QLineEdit:disabled {
    background-color: #e9ecef;
    color: #6c757d;
}

/* Text edits */
QTextEdit, QPlainTextEdit {
    background-color: white;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    padding: 8px;
    selection-background-color: #4361ee;
}

QTextEdit:focus, QPlainTextEdit:focus {
    border: 2px solid #4361ee;
    padding: 7px;
}

/* Combo boxes */
QComboBox {
    background-color: white;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    padding: 8px 12px;
    min-height: 20px;
}

QComboBox:focus {
    border: 2px solid #4361ee;
}

QComboBox::drop-down {
    border: none;
    width: 20px;
}

QComboBox::down-arrow {
    width: 12px;
    height: 12px;
}

QComboBox QAbstractItemView {
    background-color: white;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    selection-background-color: #4361ee;
    selection-color: white;
}

/* Tab widget */
QTabWidget::pane {
    border: 1px solid #dee2e6;
    border-radius: 8px;
    background-color: white;
    top: -1px;
}

QTabBar::tab {
    background-color: #e9ecef;
    border: 1px solid #dee2e6;
    border-bottom: none;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    padding: 10px 20px;
    margin-right: 2px;
    font-weight: 500;
}

QTabBar::tab:selected {
    background-color: white;
    border-bottom: 1px solid white;
}

QTabBar::tab:hover:!selected {
    background-color: #dee2e6;
}

/* Scroll areas */
QScrollArea {
    border: none;
    background-color: transparent;
}

QScrollBar:vertical {
    background-color: #f1f3f4;
    width: 10px;
    border-radius: 5px;
    margin: 0;
}

QScrollBar::handle:vertical {
    background-color: #c4c4c4;
    border-radius: 5px;
    min-height: 30px;
}

QScrollBar::handle:vertical:hover {
    background-color: #a8a8a8;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}

QScrollBar:horizontal {
    background-color: #f1f3f4;
    height: 10px;
    border-radius: 5px;
}

QScrollBar::handle:horizontal {
    background-color: #c4c4c4;
    border-radius: 5px;
    min-width: 30px;
}

QScrollBar::handle:horizontal:hover {
    background-color: #a8a8a8;
}

QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0;
}

/* List widgets */
QListWidget {
    background-color: white;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    padding: 4px;
    outline: none;
}

QListWidget::item {
    padding: 8px;
    border-radius: 4px;
}

QListWidget::item:selected {
    background-color: #4361ee;
    color: white;
}

QListWidget::item:hover:!selected {
    background-color: #e9ecef;
}

/* Group boxes */
QGroupBox {
    font-weight: 600;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    margin-top: 12px;
    padding-top: 8px;
    background-color: white;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0 8px;
    color: #1a1a2e;
}

/* Frames */
QFrame#card {
    background-color: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
}

QFrame#leftPanel {
    background-color: #f0f2f5;
    border-right: 1px solid #dee2e6;
}

QFrame#logPanel {
    background-color: #1a1a2e;
    border-radius: 8px;
}

/* Splitter */
QSplitter::handle {
    background-color: #dee2e6;
}

QSplitter::handle:horizontal {
    width: 2px;
}

QSplitter::handle:vertical {
    height: 2px;
}

/* Dialog */
QDialog {
    background-color: #f8f9fa;
}

/* Message box */
QMessageBox {
    background-color: #f8f9fa;
}

/* Tool tips */
QToolTip {
    background-color: #1a1a2e;
    color: white;
    border: none;
    border-radius: 4px;
    padding: 6px 10px;
}

/* Progress bar */
QProgressBar {
    background-color: #e9ecef;
    border: none;
    border-radius: 4px;
    height: 8px;
    text-align: center;
}

QProgressBar::chunk {
    background-color: #4361ee;
    border-radius: 4px;
}

/* Drag and drop area */
QFrame#dropArea {
    background-color: #f8f9fa;
    border: 2px dashed #c4c4c4;
    border-radius: 8px;
}

QFrame#dropArea:hover {
    border-color: #4361ee;
    background-color: #eef2ff;
}

QFrame#dropAreaActive {
    border: 2px dashed #4361ee;
    background-color: #eef2ff;
}

/* Member card */
QFrame#memberCard {
    background-color: white;
    border: 1px solid #dee2e6;
    border-radius: 8px;
}

QFrame#memberCard:hover {
    border-color: #4361ee;
    background-color: #f8f9ff;
}

/* Login panel */
QFrame#loginPanel {
    background-color: white;
    border: 1px solid #dee2e6;
    border-radius: 12px;
}
"""

# Color constants for programmatic use
COLORS = {
    'primary': '#4361ee',
    'primary_hover': '#3a56d4',
    'primary_pressed': '#2e47b0',
    'secondary': '#6c757d',
    'success': '#28a745',
    'danger': '#dc3545',
    'warning': '#ffc107',
    'info': '#17a2b8',
    'light': '#f8f9fa',
    'dark': '#1a1a2e',
    'white': '#ffffff',
    'border': '#dee2e6',
    'text': '#1a1a2e',
    'text_muted': '#6c757d',
    'background': '#f8f9fa',
}
